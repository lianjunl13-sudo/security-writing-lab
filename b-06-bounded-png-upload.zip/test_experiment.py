import struct,unittest,zlib
import experiment as e
class Tests(unittest.TestCase):
 def test_valid_minimal_rgb_png(self):self.assertEqual(e.validate_png(e.sample_png()),{'width':2,'height':2,'decoded_bytes':14,'chunks':3})
 def test_extension_or_mime_cannot_turn_html_into_png(self):
  for data in (b'<html>fake</html>',b'GIF89a'+b'x'*30):
   with self.assertRaisesRegex(e.InvalidPNG,'signature'):e.validate_png(data)
 def test_crc_corruption_rejected(self):
  data=bytearray(e.sample_png());data[-5]^=1
  with self.assertRaisesRegex(e.InvalidPNG,'crc'):e.validate_png(bytes(data))
 def test_appended_bytes_rejected(self):
  with self.assertRaisesRegex(e.InvalidPNG,'trailing'):e.validate_png(e.sample_png()+b'<script>demo</script>')
 def test_oversized_dimensions_even_tiny_file(self):
  header=struct.pack('>IIBBBBB',100000,100000,8,2,0,0,0)
  data=e.SIGNATURE+e.chunk(b'IHDR',header)+e.chunk(b'IDAT',zlib.compress(b'x'))+e.chunk(b'IEND',b'')
  with self.assertRaisesRegex(e.InvalidPNG,'dimensions'):e.validate_png(data)
 def test_decompressed_size_bomb_is_bounded(self):
  header=struct.pack('>IIBBBBB',1,1,8,2,0,0,0)
  data=e.SIGNATURE+e.chunk(b'IHDR',header)+e.chunk(b'IDAT',zlib.compress(b'x'*1000000))+e.chunk(b'IEND',b'')
  self.assertLess(len(data),2000)
  with self.assertRaisesRegex(e.InvalidPNG,'decompression_bounds'):e.validate_png(data)
 def test_unsupported_chunks_rejected_rather_than_claim_full_png(self):
  data=e.sample_png();data=data[:-12]+e.chunk(b'tEXt',b'key\0value')+data[-12:]
  with self.assertRaisesRegex(e.InvalidPNG,'unsupported_chunk'):e.validate_png(data)
 def test_chunk_length_and_missing_end_rejected(self):
  for data in (e.sample_png()[:-1],e.SIGNATURE+struct.pack('>I',0xffffffff)+b'IHDR'):
   with self.assertRaises(e.InvalidPNG):e.validate_png(data)
 def test_invalid_scanline_filter_rejected(self):
  header=struct.pack('>IIBBBBB',1,1,8,2,0,0,0)
  data=e.SIGNATURE+e.chunk(b'IHDR',header)+e.chunk(b'IDAT',zlib.compress(b'\x05\0\0\0'))+e.chunk(b'IEND',b'')
  with self.assertRaisesRegex(e.InvalidPNG,'filter_byte'):e.validate_png(data)
if __name__=='__main__':unittest.main()
