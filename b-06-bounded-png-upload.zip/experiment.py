"""Strict 8-bit RGB PNG subset with CRC, dimensions and bounded decompression."""
import binascii,json,struct,zlib
SIGNATURE=b'\x89PNG\r\n\x1a\n'
MAX_FILE=1024*1024
MAX_SIDE=1024
MAX_PIXELS=1024*1024
class InvalidPNG(ValueError): pass

def chunk(kind,data):
    return struct.pack('>I',len(data))+kind+data+struct.pack('>I',binascii.crc32(kind+data)&0xffffffff)

def sample_png(width=2,height=2):
    ihdr=struct.pack('>IIBBBBB',width,height,8,2,0,0,0)
    raw=b''.join(b'\x00'+b'\x20\x80\xc0'*width for _ in range(height))
    return SIGNATURE+chunk(b'IHDR',ihdr)+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b'')

def validate_png(data):
    if not isinstance(data,bytes) or len(data)>MAX_FILE or not data.startswith(SIGNATURE): raise InvalidPNG('size_or_signature')
    offset=8;chunks=[];compressed=[];width=height=None;ended=False
    while offset<len(data):
        if len(chunks)>=64 or offset+12>len(data): raise InvalidPNG('chunk_bounds')
        length=struct.unpack('>I',data[offset:offset+4])[0];kind=data[offset+4:offset+8]
        if offset+12+length>len(data): raise InvalidPNG('chunk_bounds')
        payload=data[offset+8:offset+8+length];expected=struct.unpack('>I',data[offset+8+length:offset+12+length])[0]
        if binascii.crc32(kind+payload)&0xffffffff!=expected: raise InvalidPNG('crc')
        if kind not in (b'IHDR',b'IDAT',b'IEND'): raise InvalidPNG('unsupported_chunk')
        if not chunks and kind!=b'IHDR': raise InvalidPNG('ihdr_first')
        if kind==b'IHDR':
            if chunks or length!=13: raise InvalidPNG('ihdr')
            width,height,depth,color,comp,filt,interlace=struct.unpack('>IIBBBBB',payload)
            if not (1<=width<=MAX_SIDE and 1<=height<=MAX_SIDE and width*height<=MAX_PIXELS): raise InvalidPNG('dimensions')
            if (depth,color,comp,filt,interlace)!=(8,2,0,0,0): raise InvalidPNG('unsupported_format')
        elif kind==b'IDAT': compressed.append(payload)
        else:
            if length or not compressed: raise InvalidPNG('iend')
            ended=True
        chunks.append(kind);offset+=12+length
        if ended: break
    if not ended or offset!=len(data): raise InvalidPNG('trailing_or_missing_iend')
    expected_size=height*(1+3*width)
    inflater=zlib.decompressobj()
    try: raw=inflater.decompress(b''.join(compressed),expected_size+1)
    except zlib.error: raise InvalidPNG('zlib') from None
    if len(raw)!=expected_size or not inflater.eof or inflater.unused_data or inflater.unconsumed_tail: raise InvalidPNG('decompression_bounds')
    row_size=1+3*width
    if any(raw[start]>4 for start in range(0,len(raw),row_size)): raise InvalidPNG('filter_byte')
    return {'width':width,'height':height,'decoded_bytes':len(raw),'chunks':len(chunks)}

if __name__=='__main__':
    valid=sample_png()
    print(json.dumps({'file_bytes':len(valid),'accepted':validate_png(valid)}))
    for label,data in [('html_named_png',b'<html>not an image</html>'),('appended_payload',valid+b'<script>synthetic</script>'),('crc_corruption',valid[:-5]+b'x'+valid[-4:])]:
        try: validate_png(data)
        except InvalidPNG as exc: print(json.dumps({'case':label,'rejected':str(exc)}))
