"""Reset URL construction from trusted site configuration, no email or token service."""
import re
from urllib.parse import urlsplit,urlunsplit,urlencode
class Rejected(ValueError):pass

def site_base(value):
    if type(value)is not str or len(value)>512 or not value.isascii() or any(ord(c)<=32 or ord(c)==127 for c in value) or any(c in value for c in '\\%?#'):
        raise Rejected('site_representation')
    try:
        p=urlsplit(value)
        if p.scheme!='https' or not p.hostname or p.username is not None or p.password is not None or p.path not in ('','/')or p.netloc.endswith(':')or p.port not in (None,443):raise Rejected('site_components')
        if not re.fullmatch('[a-z0-9.-]+',p.hostname)or p.hostname.endswith('.'):raise Rejected('site_hostname')
        return urlunsplit(('https',p.hostname,'','',''))
    except ValueError as e:
        if isinstance(e,Rejected):raise
        raise Rejected('site_parse')from None

class ResetLinks:
    def __init__(self,sites):
        if type(sites)is not dict or not sites or any(type(k)is not str for k in sites):raise Rejected('sites')
        self._sites={key:site_base(base)for key,base in sites.items()}
    def build(self,trusted_site_id,token):
        if type(trusted_site_id)is not str or trusted_site_id not in self._sites:raise Rejected('unknown_site')
        if type(token)is not str or not re.fullmatch('[A-Za-z0-9_-]{43}',token):raise Rejected('token_transport_form')
        return self._sites[trusted_site_id]+'/reset-password?'+urlencode({'token':token})

def handle_request(request_headers,*,trusted_site_id,token,builder):
    # Neither Host nor forwarded fields are a source of the public site base.
    return builder.build(trusted_site_id,token)

if __name__=='__main__':
    import json
    builder=ResetLinks({'main':'https://accounts.example','other':'https://login-beta.example'})
    token='A'*43
    cases={'normal':{'Host':'accounts.example'},'host_injected':{'Host':'attacker.invalid'},'forwarded_injected':{'Host':'internal.local','X-Forwarded-Host':'attacker.invalid','Forwarded':'host=attacker.invalid;proto=http'}}
    print(json.dumps({label:handle_request(h,trusted_site_id='main',token=token,builder=builder)for label,h in cases.items()},indent=2))
