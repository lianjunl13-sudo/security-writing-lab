import unittest
from urllib.parse import urlsplit,parse_qs
from experiment import ResetLinks,handle_request,Rejected
class ResetTests(unittest.TestCase):
    def setUp(self):self.builder=ResetLinks({'main':'https://accounts.example','other':'https://login-beta.example'});self.token='A'*43
    def request(self,headers,site='main'):return handle_request(headers,trusted_site_id=site,token=self.token,builder=self.builder)
    def test_normal(self):self.assertEqual(urlsplit(self.request({'Host':'accounts.example'})).netloc,'accounts.example')
    def test_host_ignored(self):self.assertEqual(self.request({'Host':'attacker.invalid'}),self.request({}))
    def test_x_forwarded_host_ignored(self):self.assertEqual(self.request({'X-Forwarded-Host':'attacker.invalid'}),self.request({}))
    def test_forwarded_and_proto_ignored(self):self.assertTrue(self.request({'Forwarded':'host=attacker.invalid;proto=http','X-Forwarded-Proto':'http'}).startswith('https://accounts.example/'))
    def test_duplicate_header_representation_ignored(self):self.assertEqual(self.request([('Host','one.invalid'),('Host','two.invalid')]),self.request({}))
    def test_missing_headers_not_used_as_fallback(self):self.assertEqual(self.request(None),self.request({}))
    def test_other_trusted_site(self):self.assertEqual(urlsplit(self.request({},'other')).netloc,'login-beta.example')
    def test_unknown_site_rejected(self):
        for site in ['attacker.invalid',None,{}]:
            with self.assertRaises(Rejected):self.request({},site)
    def test_single_token_query(self):self.assertEqual(parse_qs(urlsplit(self.request({})).query),{'token':[self.token]})
    def test_bad_token_transport_form(self):
        for value in ['', 'A'*42, 'A'*44, 'A'*42+'\n', 'A'*42+'&', None]:
            with self.assertRaises(Rejected):self.builder.build('main',value)
    def test_site_configuration_rejected(self):
        for base in ['http://accounts.example','https://user@accounts.example','https://accounts.example/path','https://accounts.example?x=1','https://accounts.example#x','https://accounts.example:8443','https://accounts.example:','https://accounts.example\\x']:
            with self.assertRaises(Rejected):ResetLinks({'main':base})
    def test_configuration_snapshot(self):
        sites={'main':'https://accounts.example'};b=ResetLinks(sites);sites['main']='https://attacker.invalid';self.assertTrue(b.build('main',self.token).startswith('https://accounts.example/'))
    def test_default_port_and_case(self):self.assertTrue(ResetLinks({'main':'HTTPS://ACCOUNTS.EXAMPLE:443/'}).build('main',self.token).startswith('https://accounts.example/'))
    def test_header_object_not_accessed(self):
        class Unusable:
            def __getitem__(self,k):raise AssertionError('must not inspect request headers')
        self.assertTrue(self.request(Unusable()).startswith('https://accounts.example/'))
if __name__=='__main__':unittest.main(verbosity=2)
