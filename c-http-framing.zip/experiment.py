"""Strict synthetic HTTP/1.1 request-header profile; NOT an HTTP server."""
import json
import re

TOKEN = re.compile(rb"[!#$%&'*+.^_`|~0-9A-Za-z-]+")


def request_length(raw):
    if type(raw) is not bytes or len(raw) > 8192 or not raw.endswith(b'\r\n\r\n'):
        raise ValueError('invalid_header_block')
    lines = raw[:-4].split(b'\r\n')
    if not 1 <= len(lines) <= 32: raise ValueError('header_count')
    fields = {}
    for line in lines:
        if not line or line[:1] in (b' ',b'\t') or b':' not in line: raise ValueError('bad_field_line')
        name,value = line.split(b':',1)
        if not TOKEN.fullmatch(name) or any(c < 32 or c > 126 for c in value):
            raise ValueError('bad_field_bytes')
        fields.setdefault(name.lower(),[]).append(value.strip(b' '))
    # No normalization that silently discards duplicate framing fields.
    if len(fields.get(b'host',[])) != 1 or not fields[b'host'][0]: raise ValueError('host_required_once')
    if b'transfer-encoding' in fields: raise ValueError('transfer_encoding_unsupported')
    lengths = fields.get(b'content-length',[])
    if len(lengths) > 1: raise ValueError('duplicate_content_length')
    if not lengths: return 0
    value=lengths[0]
    if not re.fullmatch(rb'[0-9]{1,4}',value) or int(value) > 4096:
        raise ValueError('invalid_or_excessive_content_length')
    return int(value)


def main():
    cases={'normal':b'Host: local.test\r\nContent-Length: 5\r\n\r\n',
           'same_duplicate':b'Host: local.test\r\nContent-Length: 5\r\ncontent-length: 5\r\n\r\n',
           'conflicting_duplicate':b'Host: local.test\r\nContent-Length: 5\r\nContent-Length: 7\r\n\r\n',
           'te_plus_cl':b'Host: local.test\r\nTransfer-Encoding: chunked\r\nContent-Length: 5\r\n\r\n'}
    result={}
    for key,raw in cases.items():
        try: result[key]={'body_bytes':request_length(raw)}
        except ValueError: result[key]={'rejected':True}
    print(json.dumps(result,indent=2))


if __name__ == '__main__': main()
