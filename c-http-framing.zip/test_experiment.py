import unittest
import experiment as app


class BoundaryTests(unittest.TestCase):
    def test_normal_and_absent_length(self):
        self.assertEqual(app.request_length(b'Host: a.test\r\nContent-Length: 5\r\n\r\n'),5)
        self.assertEqual(app.request_length(b'Host: a.test\r\n\r\n'),0)
    def test_duplicate_lengths_even_identical(self):
        for second in [b'5',b'7']:
            with self.subTest(second=second),self.assertRaises(ValueError):
                app.request_length(b'Host: a.test\r\nContent-Length: 5\r\ncontent-length: '+second+b'\r\n\r\n')
    def test_transfer_encoding_rejected(self):
        for extra in [b'',b'Content-Length: 5\r\n']:
            with self.subTest(extra=extra),self.assertRaises(ValueError):
                app.request_length(b'Host: a.test\r\nTransfer-Encoding: chunked\r\n'+extra+b'\r\n')
    def test_numeric_profile(self):
        for value in [b'-1',b'+5',b'5,5',b'5 5',b'1e3',b'4097',b'99999',b'']:
            with self.subTest(value=value),self.assertRaises(ValueError):
                app.request_length(b'Host: a.test\r\nContent-Length: '+value+b'\r\n\r\n')
    def test_host_exactly_once(self):
        for raw in [b'Content-Length: 5\r\n\r\n',b'Host: a\r\nHOST: b\r\n\r\n',b'Host: \r\n\r\n']:
            with self.subTest(raw=raw),self.assertRaises(ValueError): app.request_length(raw)
    def test_bad_lines_and_folding(self):
        for line in [b' bad: x',b'Content-Length : 5',b'X: a\nContent-Length: 5',b'X: a\x00',b'X: a\r',b'X: \xff',b'bad']:
            with self.subTest(line=line),self.assertRaises(ValueError): app.request_length(b'Host: a\r\n'+line+b'\r\n\r\n')
    def test_size_and_count(self):
        for raw in [b'Host: a\r\nX: '+b'x'*8200+b'\r\n\r\n',b'Host: a\r\n'+b'X: a\r\n'*32+b'\r\n']:
            with self.subTest(size=len(raw)),self.assertRaises(ValueError): app.request_length(raw)
    def test_repeated_nonframing_field_retained(self):
        self.assertEqual(app.request_length(b'Host: a\r\nX-Tag: one\r\nX-Tag: two\r\n\r\n'),0)


if __name__ == '__main__': unittest.main()
