# Local synthetic experiment: update-ed25519-rollback

Original local defensive demonstration and tests, produced with AI assistance. No production data, login credentials or persistent private keys. Not a production security component.

Python 3.12; original run environment and timestamps in evidence/run.json.

```sh
python3 -m pip install -r requirements-lock.txt
python3 -B -m unittest -v test_experiment.py
python3 -B experiment.py
```

Scope: 用成熟Ed25519库验证原元数据字节、绑定合成载荷，再对内存版本高水位拒绝回退

Limits:
- 密钥每轮临时生成，未读取生产私钥；公钥由可信宿主传入
- 只推进内存接收状态，不安装/执行/落盘，不覆盖崩溃恢复
- 非完整TUF，无持久防回退状态、过期冻结保护、阈值或轮换撤销

Evidence is an original local run, not a guarantee on another platform. No article or downloaded third-party source text is included.
