"""Verify synthetic signed metadata and advance in-memory version; no installer."""
import hashlib
import hmac
import json
import re
import threading

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey,Ed25519PublicKey

PRODUCT='synthetic-desktop'


class Rejected(ValueError):pass


def pairs(items):
    result={}
    for key,value in items:
        if key in result:raise Rejected('duplicate_metadata_key')
        result[key]=value
    return result


def package(private_key,version,payload,product=PRODUCT):
    metadata={'product':product,'version':version,'sha256':hashlib.sha256(payload).hexdigest(),'length':len(payload)}
    raw=json.dumps(metadata,sort_keys=True,separators=(',',':')).encode()
    return raw,private_key.sign(raw),payload


class UpdateVerifier:
    def __init__(self,trusted_public_key,installed_version=10):
        if not isinstance(trusted_public_key,Ed25519PublicKey):raise Rejected('trusted_key_type')
        if type(installed_version) is not int or not 0<=installed_version<=2**31-1:raise Rejected('installed_version')
        self.public_key=trusted_public_key;self.version=installed_version;self.payload=None;self.lock=threading.Lock()

    def accept(self,raw,signature,payload):
        if type(raw) is not bytes or not 1<=len(raw)<=4096:raise Rejected('metadata_size')
        if type(signature) is not bytes or len(signature)!=64:raise Rejected('signature_shape')
        if type(payload) is not bytes or len(payload)>65536:raise Rejected('payload_size')
        try:self.public_key.verify(signature,raw)
        except InvalidSignature:raise Rejected('signature_invalid') from None
        try:metadata=json.loads(raw.decode('utf-8'),object_pairs_hook=pairs)
        except (ValueError,UnicodeError,RecursionError) as exc:
            if isinstance(exc,Rejected):raise
            raise Rejected('metadata_invalid') from None
        if type(metadata) is not dict or set(metadata)!={'product','version','sha256','length'}:raise Rejected('metadata_fields')
        if metadata['product']!=PRODUCT:raise Rejected('wrong_product')
        version=metadata['version'];length=metadata['length'];digest=metadata['sha256']
        if type(version) is not int or not 1<=version<=2**31-1:raise Rejected('version_value')
        if type(length) is not int or length!=len(payload):raise Rejected('payload_length')
        actual=hashlib.sha256(payload).hexdigest()
        if type(digest) is not str or not re.fullmatch(r'[0-9a-f]{64}',digest) or not hmac.compare_digest(actual,digest):raise Rejected('payload_digest')
        with self.lock:
            if version<=self.version:raise Rejected('rollback_or_reinstall')
            self.version=version;self.payload=payload
        return {'accepted_version':version,'payload_bytes':len(payload)}


def main():
    private=Ed25519PrivateKey.generate();verifier=UpdateVerifier(private.public_key());out={}
    for name,bundle in [('new_version',package(private,11,b'synthetic update v11')),
                        ('repeat_version',package(private,11,b'synthetic update v11')),
                        ('older_valid_signature',package(private,9,b'synthetic update v9')),
                        ('changed_payload',(*package(private,12,b'synthetic update v12')[:2],b'changed'))]:
        try:out[name]=verifier.accept(*bundle)
        except Rejected as exc:out[name]={'rejected':str(exc)}
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
