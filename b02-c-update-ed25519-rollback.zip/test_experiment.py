import concurrent.futures
import hashlib
import json
import unittest
import experiment as app


class UpdateContractTests(unittest.TestCase):
    def setUp(self):self.private=app.Ed25519PrivateKey.generate();self.verifier=app.UpdateVerifier(self.private.public_key())
    def test_new_version(self):
        self.assertEqual(self.verifier.accept(*app.package(self.private,11,b'new')),{'accepted_version':11,'payload_bytes':3})
    def test_rollback_and_reinstall(self):
        for version in [9,10]:
            with self.subTest(version=version),self.assertRaisesRegex(app.Rejected,'rollback_or_reinstall'):self.verifier.accept(*app.package(self.private,version,b'old'))
    def test_changed_payload_same_length(self):
        raw,sig,_=app.package(self.private,11,b'abc')
        with self.assertRaisesRegex(app.Rejected,'payload_digest'):self.verifier.accept(raw,sig,b'abd')
        self.assertEqual(self.verifier.version,10)
    def test_changed_metadata_and_wrong_key(self):
        raw,sig,payload=app.package(self.private,11,b'new')
        with self.assertRaisesRegex(app.Rejected,'signature_invalid'):self.verifier.accept(raw.replace(b'11',b'12'),sig,payload)
        other=app.Ed25519PrivateKey.generate()
        with self.assertRaisesRegex(app.Rejected,'signature_invalid'):self.verifier.accept(*app.package(other,11,b'new'))
    def test_wrong_product(self):
        with self.assertRaisesRegex(app.Rejected,'wrong_product'):self.verifier.accept(*app.package(self.private,11,b'new',product='other-product'))
    def test_signed_invalid_metadata(self):
        raws=[b'{"version":11,"version":12}',b'[]',b'{"version":NaN}']
        for raw in raws:
            with self.subTest(raw=raw),self.assertRaises(app.Rejected):self.verifier.accept(raw,self.private.sign(raw),b'')
        for version in [True,0,2**31]:
            with self.subTest(version=version),self.assertRaises(app.Rejected):self.verifier.accept(*app.package(self.private,version,b'new'))
    def test_signature_and_size_limits(self):
        raw,sig,payload=app.package(self.private,11,b'new')
        for values in [(raw,sig[:-1],payload),(b'x'*4097,sig,payload),(raw,sig,b'x'*65537)]:
            with self.subTest(size=[len(x) for x in values]),self.assertRaises(app.Rejected):self.verifier.accept(*values)
    def test_signed_malformed_digest(self):
        for digest in ['汉'*64,'g'*64,'a'*63,True]:
            raw=json.dumps({'product':app.PRODUCT,'version':11,'length':0,'sha256':digest}).encode()
            with self.subTest(digest=digest),self.assertRaisesRegex(app.Rejected,'payload_digest'):self.verifier.accept(raw,self.private.sign(raw),b'')
    def test_parallel_same_version(self):
        bundle=app.package(self.private,11,b'new')
        def attempt(_):
            try:self.verifier.accept(*bundle);return 'accepted'
            except app.Rejected:return 'rejected'
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:results=list(pool.map(attempt,range(8)))
        self.assertEqual(results.count('accepted'),1);self.assertEqual(self.verifier.version,11)
    def test_accepts_exact_signed_whitespace(self):
        payload=b'new';raw=json.dumps({'version':11,'product':app.PRODUCT,'sha256':hashlib.sha256(payload).hexdigest(),'length':3},indent=2).encode()
        self.verifier.accept(raw,self.private.sign(raw),payload)


if __name__=='__main__':unittest.main()
