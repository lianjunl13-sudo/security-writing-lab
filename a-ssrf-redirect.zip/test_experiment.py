import unittest
from experiment import plan,follow,Rejected
class AdmissionTests(unittest.TestCase):
    def setUp(self):self.dns={'public.example':['93.184.216.34'],'other.example':['1.1.1.1'],'local.example':['127.0.0.1']};self.resolve=self.dns.__getitem__
    def reject(self,url):
        with self.assertRaises(Rejected):plan(url,self.resolve)
    def test_public_pinned(self):self.assertEqual(plan('https://public.example',self.resolve)['validated_addresses'],('93.184.216.34',))
    def test_credentials(self):self.reject('https://u:p@public.example')
    def test_http(self):self.reject('http://public.example')
    def test_port(self):self.reject('https://public.example:8443')
    def test_fragment(self):self.reject('https://public.example/#x')
    def test_controls_and_slashes(self):
        for u in ['https://public.example/\n','https://public.example\\@local.example']:self.reject(u)
    def test_nonpublic_classes(self):
        for a in ['127.0.0.1','10.0.0.1','169.254.169.254','::1','fc00::1','ff02::1','0.0.0.0']:
            with self.assertRaises(Rejected):plan('https://public.example',lambda h:[a])
    def test_mixed_answer(self):
        with self.assertRaises(Rejected):plan('https://public.example',lambda h:['1.1.1.1','10.0.0.2'])
    def test_empty_or_bad_answer(self):
        for answer in [[],['invalid']]:
            with self.assertRaises(Rejected):plan('https://public.example',lambda h:answer)
    def test_redirect_block_before_transport(self):
        calls=[]
        def request(p):calls.append(p);return 302,'https://local.example/secret'
        with self.assertRaises(Rejected):follow('https://public.example/a',self.resolve,request)
        self.assertEqual(len(calls),1)
    def test_relative_redirect(self):
        calls=[]
        def request(p):calls.append(p['url']);return (302,'/b') if len(calls)==1 else (200,None)
        self.assertEqual(follow('https://public.example/a',self.resolve,request),200)
        self.assertEqual(calls[-1],'https://public.example/b')
    def test_every_hop_resolves_again(self):
        n=[0];calls=[]
        def resolve(h):n[0]+=1;return ['1.1.1.1'] if n[0]==1 else ['127.0.0.1']
        with self.assertRaises(Rejected):follow('https://public.example/a',resolve,lambda p:(calls.append(p) or (302,'/b')))
        self.assertEqual(len(calls),1)
    def test_loop_or_budget(self):
        with self.assertRaises(Rejected):follow('https://public.example/a',self.resolve,lambda p:(302,'/a'))
        with self.assertRaises(Rejected):follow('https://public.example/a',self.resolve,lambda p:(302,'/b'),0)
if __name__=='__main__':unittest.main(verbosity=2)
