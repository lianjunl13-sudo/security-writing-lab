"""URL admission and redirect planning; no networking or real-target scanning."""
import ipaddress
import re
from urllib.parse import urlsplit, urljoin

class Rejected(ValueError): pass

def plan(url, resolve):
    if not isinstance(url,str) or len(url)>2048 or any(ord(c)<33 for c in url) or '\\' in url:
        raise Rejected('unsafe URL representation')
    try:
        p=urlsplit(url)
        host=p.hostname
        port=p.port
        if p.scheme!='https' or not host or p.username is not None or p.password is not None or port not in (None,443):
            raise Rejected('scheme, authority or port')
        if p.fragment or '%' in p.netloc or not host.isascii() or host.endswith('.'):
            raise Rejected('ambiguous authority')
        if ':' not in host and not re.fullmatch(r'[a-zA-Z0-9.-]+',host):
            raise Rejected('hostname syntax')
        addresses=tuple(resolve(host))
        if not addresses: raise Rejected('empty DNS answer')
        for address in addresses:
            ip=ipaddress.ip_address(address)
            if not ip.is_global or ip.is_multicast or ip.is_unspecified:
                raise Rejected('non-public address')
        return {'url':url,'host':host,'port':443,'validated_addresses':addresses}
    except (ValueError,TypeError) as e:
        if isinstance(e,Rejected):raise
        raise Rejected('invalid URL or address') from None

def follow(url,resolve,request,max_redirects=3):
    """request must connect only to validated_addresses, preserving TLS host checks."""
    if type(max_redirects) is not int or not 0<=max_redirects<=10:raise Rejected('redirect budget')
    seen=set()
    for hop in range(max_redirects+1):
        admission=plan(url,resolve)
        if url in seen:raise Rejected('redirect loop')
        seen.add(url)
        status,location=request(admission)
        if status not in (301,302,303,307,308):return status
        if not isinstance(location,str) or not location or hop==max_redirects:raise Rejected('redirect budget or location')
        url=urljoin(url,location)
    raise Rejected('unreachable')

if __name__=='__main__':
    import json
    dns={'public.example':['93.184.216.34'],'internal.example':['127.0.0.1'],'mixed.example':['93.184.216.34','10.0.0.1']}
    output={}
    for label,url in [('public','https://public.example/a'),('loopback','https://internal.example/a'),('mixed_dns','https://mixed.example/a')]:
        try:plan(url,dns.__getitem__);output[label]='admitted'
        except Rejected:output[label]='rejected'
    calls=[]
    def transport(p):calls.append(p['host']);return 302,'https://internal.example/private'
    try:follow('https://public.example/a',dns.__getitem__,transport)
    except Rejected:output['redirect_to_loopback']='rejected before second request'
    output['transport_calls']=calls
    print(json.dumps(output,ensure_ascii=False,indent=2))
