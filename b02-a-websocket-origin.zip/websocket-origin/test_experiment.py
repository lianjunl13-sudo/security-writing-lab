import unittest
from experiment import admit,Rejected
class OriginTests(unittest.TestCase):
    def ok(self,origin):return admit([('Origin',origin)])
    def no(self,origin):
        with self.assertRaises(Rejected):self.ok(origin)
    def test_exact_allowed(self):self.assertEqual(self.ok('https://app.example')['status'],'origin_admitted')
    def test_second_allowed(self):self.assertEqual(self.ok('https://console.example')['origin'][1],'console.example')
    def test_case_and_default_port(self):self.assertEqual(self.ok('HTTPS://APP.EXAMPLE:443'),self.ok('https://app.example'))
    def test_missing(self):
        with self.assertRaisesRegex(Rejected,'exactly_one'):admit([])
    def test_duplicate_identical(self):
        with self.assertRaisesRegex(Rejected,'exactly_one'):admit([('Origin','https://app.example'),('ORIGIN','https://app.example')])
    def test_duplicate_conflict(self):
        with self.assertRaises(Rejected):admit([('Origin','https://app.example'),('origin','https://evil.test')])
    def test_lookalike_and_wrong_port(self):
        for v in ['https://app.example.evil.test','https://evilapp.example','https://app.example:8443']:self.no(v)
    def test_http_null_and_credentials(self):
        for v in ['http://app.example','wss://app.example','null','https://x@app.example']:self.no(v)
    def test_path_query_and_fragment(self):
        for v in ['https://app.example/','https://app.example?a=1','https://app.example#x','https://app.example?','https://app.example#','https://app.example:']:self.no(v)
    def test_origin_list_or_controls(self):
        for v in ['https://app.example,https://evil.test',' https://app.example','https://app.example\r\nX:y']:self.no(v)
    def test_representation(self):
        for v in ['https://app.example.','https://app%2eexample','https://ａｐｐ.example','https://app.example\\x']:self.no(v)
    def test_header_budget(self):
        with self.assertRaises(Rejected):admit([('X','x')]*65)
    def test_bad_container_or_pair(self):
        for v in [{},[('Origin',)],[(1,'x')],[(' Origin','https://app.example')]]:
            with self.assertRaises(Rejected):admit(v)
    def test_header_name_case(self):self.assertEqual(admit([('oRiGiN','https://app.example')])['status'],'origin_admitted')
if __name__=='__main__':unittest.main(verbosity=2)
