"""Browser-facing WebSocket Origin admission, not an HTTP server or authenticator."""
import re
from urllib.parse import urlsplit
ALLOWED={('https','app.example',443),('https','console.example',443)}
class Rejected(ValueError):pass

def origin_key(value):
    if type(value)is not str or not 1<=len(value)<=512 or not value.isascii() or any(ord(c)<=32 or ord(c)==127 for c in value) or '\\'in value or '?'in value or '#'in value:
        raise Rejected('origin_representation')
    try:
        p=urlsplit(value)
        if p.scheme!='https' or not p.hostname or p.username is not None or p.password is not None or p.path or p.query or p.fragment or '%'in p.netloc or p.netloc.endswith(':'):
            raise Rejected('serialized_origin_required')
        if not re.fullmatch(r'[a-z0-9.-]+',p.hostname) or p.hostname.endswith('.'):
            raise Rejected('host_policy')
        return p.scheme,p.hostname,p.port if p.port is not None else 443
    except ValueError as e:
        if isinstance(e,Rejected):raise
        raise Rejected('origin_parse')from None

def admit(headers):
    if type(headers)is not list or len(headers)>64:raise Rejected('header_container')
    origins=[]
    for pair in headers:
        if type(pair)not in (tuple,list)or len(pair)!=2 or any(type(v)is not str for v in pair):raise Rejected('header_pair')
        name,value=pair
        if not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+",name):raise Rejected('header_name')
        if name.lower()=='origin':origins.append(value)
    if len(origins)!=1:raise Rejected('exactly_one_origin_required')
    key=origin_key(origins[0])
    if key not in ALLOWED:raise Rejected('origin_not_allowed')
    return {'status':'origin_admitted','origin':list(key)}

if __name__=='__main__':
    import json
    cases={'allowed':[('Origin','https://app.example')], 'default_port':[('Origin','https://APP.example:443')], 'missing':[], 'duplicate':[('Origin','https://app.example'),('origin','https://app.example')], 'lookalike':[('Origin','https://app.example.evil.test')], 'opaque':[('Origin','null')]}
    result={}
    for label,headers in cases.items():
        try:result[label]=admit(headers)
        except Rejected as e:result[label]={'status':'rejected','reason':str(e)}
    print(json.dumps(result,ensure_ascii=False,indent=2))
