import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from experiment import parse_note, NoteRejected, local_file_baseline, MAX_BYTES

class NoteTests(unittest.TestCase):
    def rejected(self, data, code, audit=None):
        with self.assertRaisesRegex(NoteRejected, '^' + code + '$'):
            parse_note(data, audit=audit)

    def test_normal_chinese(self):
        self.assertEqual(parse_note('<note>工单已复核</note>'.encode()), '工单已复核')

    def test_predefined_ampersand(self):
        self.assertEqual(parse_note(b'<note>A &amp; B</note>'), 'A & B')

    def test_empty_and_cdata(self):
        self.assertEqual(parse_note(b'<note/>'), '')
        self.assertEqual(parse_note(b'<note><![CDATA[A < B]]></note>'), 'A < B')

    def test_local_file_contrast_and_zero_safe_resolutions(self):
        with TemporaryDirectory() as folder:
            p=Path(folder)/'only-synthetic.txt';p.write_text('SYNTHETIC_ONLY')
            payload, baseline=local_file_baseline(p)
            self.assertEqual(baseline, 'SYNTHETIC_ONLY')
            audit=[];self.rejected(payload,'doctype_forbidden',audit)
            self.assertEqual(audit, [])

    def test_external_dtd_never_loaded(self):
        with TemporaryDirectory() as folder:
            p=Path(folder)/'synthetic.dtd';p.write_text('<!ENTITY sample "SYNTHETIC">')
            payload=('<!DOCTYPE note SYSTEM "'+p.as_uri()+'"><note>ordinary</note>').encode()
            audit=[];self.rejected(payload,'doctype_forbidden',audit)
            self.assertEqual(audit, [])

    def test_internal_entity_forbidden(self):
        audit=[]
        self.rejected(b'<!DOCTYPE note [<!ENTITY x "local">]><note>&x;</note>', 'doctype_forbidden',audit)
        self.assertEqual(audit, [])

    def test_utf16_doctype_not_bypassed(self):
        self.rejected('<!DOCTYPE note [<!ENTITY x "local">]><note>&x;</note>'.encode('utf-16'),'doctype_forbidden')

    def test_utf16_regular_note(self):
        self.assertEqual(parse_note('<note>普通文本</note>'.encode('utf-16')), '普通文本')

    def test_doctype_without_entities_forbidden(self):
        self.rejected(b'<!DOCTYPE note><note>hello</note>', 'doctype_forbidden')

    def test_malformed_not_recovered(self):
        for payload in [b'<note>broken',b'<note>&unknown;</note>',b'<note></note><other/>',b'\xff']:
            with self.subTest(payload=payload):self.rejected(payload,'malformed_xml')

    def test_root_attributes_children_and_namespaces_forbidden(self):
        for payload in [b'<ticket/>',b'<note id="1"/>',b'<note><b>bold</b></note>',b'<note xmlns="urn:other"/>',b'<note><!--hidden--></note>',b'<note><?instruction test?></note>']:
            with self.subTest(payload=payload):self.rejected(payload,'note_shape')

    def test_siblings_forbidden(self):
        for payload in [b'<!--head--><note/>',b'<note/><?tail data?>']:
            with self.subTest(payload=payload):self.rejected(payload,'note_shape')

    def test_bytes_and_nonempty_budget(self):
        for payload in ['<note/>',None,bytearray(b'<note/>')]:self.rejected(payload,'bytes_required')
        self.rejected(b'','input_size')
        self.rejected(b'x'*(MAX_BYTES+1),'input_size')

    def test_exact_budget_valid(self):
        payload=b'<note>'+b'a'*(MAX_BYTES-len(b'<note></note>'))+b'</note>'
        self.assertEqual(len(payload),MAX_BYTES)
        self.assertEqual(len(parse_note(payload)),MAX_BYTES-len(b'<note></note>'))

if __name__=='__main__':unittest.main()
