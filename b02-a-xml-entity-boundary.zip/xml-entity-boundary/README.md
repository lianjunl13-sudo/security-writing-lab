# xml-entity-boundary 本地合成数据实验

本附件只含原创代码、测试、实际运行记录及适用的依赖锁。没有文章正文或外部来源全文，没有真实用户资料、生产凭据或私钥。AI辅助编写；测试实际执行。

本次环境 Python 3.12.14 / lxml 6.1.3 / libxml2 2.14.6。requirements.lock 仅含本次 macOS cp312 universal2 轮子哈希；其他平台需从官方PyPI重新核对并锁定相应轮子。

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip --isolated --require-hashes --only-binary=:all: --no-deps --index-url https://pypi.org/simple -r requirements.lock
.venv/bin/python -B -m unittest -v
.venv/bin/python -B experiment.py
```

对照函数显式启用实体展开，仅用于程序新建的合成临时文件；业务入口应使用parse_note。

范围：仅本地合成输入。没有浏览器、真实网络服务或生产环境集成验证；实际解释器、时间、源码摘要见evidence/run.json。
