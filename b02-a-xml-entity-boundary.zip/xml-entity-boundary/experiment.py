"""Bounded XML note importer; local synthetic evidence only."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json
from lxml import etree

MAX_BYTES = 8192

class NoteRejected(ValueError):
    pass

class RejectExternal(etree.Resolver):
    def __init__(self, audit):
        super().__init__()
        self.audit = audit

    def resolve(self, url, public_id, context):
        self.audit.append(url)
        raise NoteRejected('external_resource_forbidden')

def parse_note(data, *, audit=None):
    """Return plain note text; never pass parsed trees to downstream code."""
    if type(data) is not bytes:
        raise NoteRejected('bytes_required')
    if not data or len(data) > MAX_BYTES:
        raise NoteRejected('input_size')
    calls = [] if audit is None else audit
    parser = etree.XMLParser(resolve_entities=False, no_network=True,
                             load_dtd=False, huge_tree=False, recover=False)
    parser.resolvers.add(RejectExternal(calls))
    try:
        root = etree.fromstring(data, parser=parser)
    except etree.XMLSyntaxError as exc:
        raise NoteRejected('malformed_xml') from exc
    if root.getroottree().docinfo.doctype:
        raise NoteRejected('doctype_forbidden')
    if root.tag != 'note' or root.attrib or len(root):
        raise NoteRejected('note_shape')
    # Comments / PIs before or after root are outside this import format.
    if root.getprevious() is not None or root.getnext() is not None:
        raise NoteRejected('note_shape')
    return root.text or ''

def local_file_baseline(path):
    """Deliberately unsafe contrast, ONLY with generated test data."""
    payload = ('<!DOCTYPE note [<!ENTITY sample SYSTEM "' +
               path.as_uri() + '">]><note>&sample;</note>').encode()
    parser = etree.XMLParser(resolve_entities=True, load_dtd=True,
                             no_network=True, huge_tree=False, recover=False)
    root = etree.fromstring(payload, parser=parser)
    return payload, root.text

def demo():
    with TemporaryDirectory(prefix='xml-note-demo-') as folder:
        sentinel = Path(folder)/'synthetic.txt'
        sentinel.write_text('LOCAL_SYNTHETIC_SENTINEL', encoding='utf-8')
        payload, baseline = local_file_baseline(sentinel)
        audit = []
        try:
            safe = {'text': parse_note(payload, audit=audit)}
        except NoteRejected as exc:
            safe = {'rejected': str(exc)}
        return {'versions': {'lxml': etree.LXML_VERSION,
                              'libxml_runtime': etree.LIBXML_VERSION,
                              'libxml_compiled': etree.LIBXML_COMPILED_VERSION},
                'baseline_no_network_reads_generated_local_file': baseline == 'LOCAL_SYNTHETIC_SENTINEL',
                'safe_same_payload': safe,
                'safe_resolver_calls': len(audit),
                'normal_note': parse_note('<note>工单已处理 &amp; 已复核</note>'.encode())}

if __name__ == '__main__':
    print(json.dumps(demo(), ensure_ascii=False, indent=2))
