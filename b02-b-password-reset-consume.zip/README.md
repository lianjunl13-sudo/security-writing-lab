# password-reset-consume: reproducible synthetic experiment

Original defensive engineering code and tests. No article body or third-party source documents included.

## Run

Python 3.12 was used for the recorded run. In this folder:

    python -B -m unittest -v test_experiment.py
    python -B experiment.py

## Evidence and boundaries

Observed tests/demos used only synthetic inputs. evidence/run.json redacts local path strings only; timestamps, environment versions, code hashes and stdout/stderr hashes are retained.

- 仅模拟内部签发与消费；没有公开找回接口、邮件发送或账户枚举保护。
- 密码散列是合成占位值；不能让客户端提供可信散列值。
- 凭据版本写入不等于会话已失效；需要会话逻辑接入。
- 十二并发结果针对当前 SQLite 实验；没有分布式故障或容量测试。

AI-assisted original code; local tests actually executed. No production deployment or universal security certification is claimed.
