"""Synthetic reset credential flow: digest storage and one SQLite commit boundary."""
import hashlib,json,re,secrets,sqlite3,tempfile,threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from contextlib import contextmanager
@contextmanager
def connection(*args, **kwargs):
    db=sqlite3.connect(*args, **kwargs)
    try:
        with db:
            yield db
    finally:
        db.close()

class InvalidReset(ValueError):pass

def clock_value(now):
    if type(now) is not int or not 0<=now<=253402300799:raise ValueError('invalid_clock')

def initialize(path):
    with connection(path) as db:
        db.executescript("CREATE TABLE accounts(user_id TEXT PRIMARY KEY,password_hash TEXT NOT NULL,credential_version INTEGER NOT NULL);"
                         "INSERT INTO accounts VALUES('synthetic-user','synthetic-old-hash',1);"
                         "CREATE TABLE resets(digest TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires_at INTEGER NOT NULL,consumed_at INTEGER,revoked INTEGER NOT NULL);")

def issue(path,user_id,*,now,ttl=900):
    clock_value(now)
    if type(ttl) is not int or not 1<=ttl<=900:raise ValueError('invalid_ttl')
    raw=secrets.token_urlsafe(32);digest=hashlib.sha256(raw.encode('ascii')).hexdigest()
    with connection(path,timeout=5,isolation_level=None) as db:
        try:
            db.execute('BEGIN IMMEDIATE')
            if not db.execute('SELECT 1 FROM accounts WHERE user_id=?',(user_id,)).fetchone():raise InvalidReset('invalid_reset')
            db.execute('UPDATE resets SET revoked=1 WHERE user_id=? AND consumed_at IS NULL',(user_id,))
            db.execute('INSERT INTO resets VALUES(?,?,?,NULL,0)',(digest,user_id,now+ttl))
            db.execute('COMMIT')
        except Exception:
            if db.in_transaction:db.execute('ROLLBACK')
            raise
    return raw

def consume(path,raw,*,now,new_password_hash,fail=False):
    clock_value(now)
    if not isinstance(raw,str) or not re.fullmatch(r'[A-Za-z0-9_-]{43}',raw):raise InvalidReset('invalid_reset')
    # This argument is a synthetic stand-in for a trusted password-hashing service.
    if type(new_password_hash) is not str or not 1<=len(new_password_hash)<=256:raise ValueError('invalid_hash')
    digest=hashlib.sha256(raw.encode('ascii')).hexdigest()
    db=sqlite3.connect(path,timeout=5,isolation_level=None)
    try:
        db.execute('BEGIN IMMEDIATE')
        row=db.execute('UPDATE resets SET consumed_at=? WHERE digest=? AND consumed_at IS NULL AND revoked=0 AND expires_at>? RETURNING user_id',(now,digest,now)).fetchone()
        if not row:raise InvalidReset('invalid_reset')
        if fail:raise RuntimeError('synthetic_failure_after_consume')
        changed=db.execute('UPDATE accounts SET password_hash=?,credential_version=credential_version+1 WHERE user_id=?',(new_password_hash,row[0])).rowcount
        if changed!=1:raise InvalidReset('invalid_reset')
        db.execute('COMMIT');return row[0]
    except Exception:
        if db.in_transaction:db.execute('ROLLBACK')
        raise
    finally:db.close()

def concurrent_consume(path,raw,now=101,workers=12):
    barrier=threading.Barrier(workers)
    def worker(_):
        barrier.wait()
        try:consume(path,raw,now=now,new_password_hash='synthetic-new-hash');return 'accepted'
        except InvalidReset:return 'rejected'
    with ThreadPoolExecutor(max_workers=workers) as pool:results=list(pool.map(worker,range(workers)))
    return {'requests':workers,'accepted':results.count('accepted'),'rejected':results.count('rejected')}

if __name__=='__main__':
    with tempfile.TemporaryDirectory() as temp:
        path=Path(temp)/'demo.db';initialize(path);raw=issue(path,'synthetic-user',now=100)
        result=concurrent_consume(path,raw)
        with connection(path) as db:
            result['credential_version']=db.execute('SELECT credential_version FROM accounts').fetchone()[0]
            result['raw_token_present_in_logical_dump']=raw in '\n'.join(db.iterdump())
        print(json.dumps(result))
        expiring=issue(path,'synthetic-user',now=200,ttl=1)
        try:consume(path,expiring,now=201,new_password_hash='synthetic-next-hash')
        except InvalidReset:print('at_expiry=invalid_reset')
