import hashlib,sqlite3,tempfile,unittest
from pathlib import Path
import experiment as e

class ResetTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'state.db';e.initialize(self.path)
    def token(self,**kw):return e.issue(self.path,'synthetic-user',now=100,**kw)
    def consume(self,token,now=101,**kw):return e.consume(self.path,token,now=now,new_password_hash='synthetic-new',**kw)
    def account(self):
        with e.connection(self.path) as db:return db.execute('SELECT password_hash,credential_version FROM accounts').fetchone()
    def test_digest_only_at_rest(self):
        raw=self.token()
        with e.connection(self.path) as db:
            dump='\n'.join(db.iterdump());digest=db.execute('SELECT digest FROM resets').fetchone()[0]
        self.assertNotIn(raw,dump);self.assertEqual(digest,hashlib.sha256(raw.encode()).hexdigest());self.assertEqual(len(raw),43)
    def test_success_and_sequential_replay(self):
        raw=self.token();self.assertEqual(self.consume(raw),'synthetic-user')
        with self.assertRaises(e.InvalidReset):self.consume(raw)
        self.assertEqual(self.account(),('synthetic-new',2))
    def test_twelve_concurrent_requests_one_commit(self):
        self.assertEqual(e.concurrent_consume(self.path,self.token()),{'requests':12,'accepted':1,'rejected':11})
        self.assertEqual(self.account()[1],2)
    def test_exact_expiry_is_rejected_and_before_allowed(self):
        raw=self.token(ttl=2)
        with self.assertRaises(e.InvalidReset):self.consume(raw,now=102)
        self.assertEqual(self.consume(raw,now=101),'synthetic-user')
    def test_new_issue_revokes_prior_token(self):
        first=self.token();second=self.token()
        with self.assertRaises(e.InvalidReset):self.consume(first)
        self.assertEqual(self.consume(second),'synthetic-user')
    def test_failure_rolls_back_consumption_and_password(self):
        raw=self.token()
        with self.assertRaisesRegex(RuntimeError,'synthetic_failure'):self.consume(raw,fail=True)
        self.assertEqual(self.account(),('synthetic-old-hash',1))
        with e.connection(self.path) as db:self.assertIsNone(db.execute('SELECT consumed_at FROM resets').fetchone()[0])
        self.assertEqual(self.consume(raw),'synthetic-user')
    def test_unknown_token_and_bad_format_leave_account_unchanged(self):
        for raw in ['A'*43,'','a'*42,'a'*44,'汉'*43,123,None]:
            with self.subTest(raw=type(raw).__name__),self.assertRaises(e.InvalidReset):self.consume(raw)
        self.assertEqual(self.account(),('synthetic-old-hash',1))
    def test_unknown_account_does_not_revoke_existing(self):
        raw=self.token()
        with self.assertRaises(e.InvalidReset):e.issue(self.path,'missing',now=100)
        self.assertEqual(self.consume(raw),'synthetic-user')
    def test_input_boundaries(self):
        for now in [True,-1,1.0,253402300800]:
            with self.subTest(now=now),self.assertRaises(ValueError):e.issue(self.path,'synthetic-user',now=now)
        for ttl in [True,0,901,1.0]:
            with self.subTest(ttl=ttl),self.assertRaises(ValueError):self.token(ttl=ttl)
        raw=self.token()
        for value in ['', 'x'*257, None]:
            with self.subTest(value=type(value).__name__),self.assertRaises(ValueError):e.consume(self.path,raw,now=101,new_password_hash=value)
        self.assertEqual(self.consume(raw),'synthetic-user')
if __name__=='__main__':unittest.main(verbosity=2)
