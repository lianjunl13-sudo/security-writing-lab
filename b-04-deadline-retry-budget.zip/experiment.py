"""Deterministic retry scheduling; injected operations must honor timeout."""
import json
class Retryable(Exception): pass
class DeadlineExceeded(TimeoutError): pass

class FakeClock:
    def __init__(self): self.value=0.0;self.sleeps=[]
    def now(self): return self.value
    def sleep(self,seconds): self.sleeps.append(seconds);self.value+=seconds

def retry(operation,*,now,sleep,total_budget=2.5,max_attempts=3,attempt_timeout=1.0,base_delay=0.2,idempotent=False):
    if not idempotent: raise ValueError('idempotency_required')
    if type(max_attempts) is not int or max_attempts<1 or min(total_budget,attempt_timeout,base_delay)<=0: raise ValueError('config')
    deadline=now()+total_budget;attempts=0;trace=[]
    while attempts<max_attempts:
        remaining=deadline-now()
        if remaining<=0: raise DeadlineExceeded('deadline_before_attempt')
        timeout=min(attempt_timeout,remaining);attempts+=1
        trace.append({'attempt':attempts,'timeout':round(timeout,6),'started':round(now(),6)})
        try:
            value=operation(timeout)
            if now()>deadline: raise DeadlineExceeded('late_success_discarded')
            return value,trace
        except Retryable:
            if attempts>=max_attempts: raise
            delay=base_delay*(2**(attempts-1))
            remaining=deadline-now()
            if remaining<=delay: raise DeadlineExceeded('insufficient_budget_for_backoff') from None
            sleep(delay)
    raise AssertionError('unreachable')

def scripted(clock,steps):
    calls=[]
    def operation(timeout):
        duration,outcome=steps[len(calls)];calls.append(timeout)
        clock.value+=min(duration,timeout)
        if duration>timeout: raise Retryable('per_attempt_timeout')
        if outcome=='retry': raise Retryable('transient')
        if outcome=='fatal': raise ValueError('fatal')
        return outcome
    return operation,calls

if __name__=='__main__':
    clock=FakeClock();operation,calls=scripted(clock,[(0.6,'retry'),(0.6,'retry'),(0.4,'ok')])
    value,trace=retry(operation,now=clock.now,sleep=clock.sleep,idempotent=True)
    print(json.dumps({'value':value,'trace':trace,'backoff':clock.sleeps,'elapsed_fake_seconds':round(clock.now(),6)}))
    clock=FakeClock();operation,calls=scripted(clock,[(1.0,'retry')]*3)
    try: retry(operation,now=clock.now,sleep=clock.sleep,total_budget=1.1,idempotent=True)
    except DeadlineExceeded as exc: print(json.dumps({'stopped':str(exc),'attempts':len(calls),'elapsed_fake_seconds':clock.now()}))
