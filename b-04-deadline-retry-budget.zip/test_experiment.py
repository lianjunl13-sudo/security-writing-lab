import unittest
import experiment as e
class Tests(unittest.TestCase):
 def call(self,steps,**kwargs):
  clock=e.FakeClock();operation,calls=e.scripted(clock,steps)
  result=e.retry(operation,now=clock.now,sleep=clock.sleep,idempotent=True,**kwargs)
  return clock,calls,result
 def test_three_attempts_success_under_total_deadline(self):
  clock,calls,(value,trace)=self.call([(0.6,'retry'),(0.6,'retry'),(0.4,'ok')])
  self.assertEqual(value,'ok');self.assertEqual(len(calls),3);self.assertAlmostEqual(clock.now(),2.2);self.assertLess(trace[-1]['timeout'],1)
 def test_backoff_does_not_exceed_remaining_budget(self):
  clock=e.FakeClock();operation,calls=e.scripted(clock,[(1,'retry')]*3)
  with self.assertRaisesRegex(e.DeadlineExceeded,'backoff'):e.retry(operation,now=clock.now,sleep=clock.sleep,total_budget=1.1,idempotent=True)
  self.assertEqual(len(calls),1);self.assertFalse(clock.sleeps);self.assertEqual(clock.now(),1)
 def test_attempt_count_caps_even_fast_failures(self):
  clock=e.FakeClock();operation,calls=e.scripted(clock,[(0,'retry')]*10)
  with self.assertRaises(e.Retryable):e.retry(operation,now=clock.now,sleep=clock.sleep,idempotent=True)
  self.assertEqual(len(calls),3)
 def test_fatal_errors_not_retried(self):
  clock=e.FakeClock();operation,calls=e.scripted(clock,[(0.1,'fatal')])
  with self.assertRaises(ValueError):e.retry(operation,now=clock.now,sleep=clock.sleep,idempotent=True)
  self.assertEqual(len(calls),1)
 def test_unsafe_operation_refused_before_call(self):
  with self.assertRaisesRegex(ValueError,'idempotency'):e.retry(lambda timeout:self.fail('called'),now=lambda:0,sleep=lambda _:None)
 def test_timeout_is_bounded_by_remaining(self):
  clock,calls,result=self.call([(0.4,'ok')],total_budget=0.5,attempt_timeout=10)
  self.assertEqual(calls,[0.5])
 def test_noncooperative_late_success_is_rejected_but_not_cancelled(self):
  clock=e.FakeClock()
  def operation(timeout):clock.value+=10;return 'late'
  with self.assertRaisesRegex(e.DeadlineExceeded,'late_success'):e.retry(operation,now=clock.now,sleep=clock.sleep,total_budget=1,idempotent=True)
  self.assertEqual(clock.now(),10)
if __name__=='__main__':unittest.main()
