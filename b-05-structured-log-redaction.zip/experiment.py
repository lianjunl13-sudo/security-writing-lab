"""Redact before formatting and writing; unknown fields are dropped."""
import json,re
from urllib.parse import parse_qsl,urlsplit,urlunsplit,urlencode
REDACTED='[REDACTED]'
SENSITIVE={'password','passwd','token','access_token','refresh_token','authorization','cookie','secret','api_key'}
ALLOWED={'event','request_id','status','method','url','details','duration_ms'}

def normalized(key): return re.sub(r'[^a-z0-9]','',key.casefold())
def is_sensitive(key): return normalized(key) in {normalized(value) for value in SENSITIVE}
def safe_url(value):
    if type(value) is not str: return '[INVALID_URL]'
    try:
        parts=urlsplit(value)
        if parts.scheme not in ('http','https') or not parts.hostname: return '[INVALID_URL]'
        netloc=parts.hostname
        if ':' in netloc: netloc='['+netloc+']'
        if parts.port: netloc+=':'+str(parts.port)
        pairs=[(key,REDACTED if is_sensitive(key) else val) for key,val in parse_qsl(parts.query,keep_blank_values=True,max_num_fields=50)]
        return urlunsplit((parts.scheme,netloc,parts.path,urlencode(pairs),''))
    except (ValueError,TypeError): return '[INVALID_URL]'

def clean(value,depth=0):
    if depth>5: return '[DEPTH_LIMIT]'
    if isinstance(value,dict):
        return {str(key):REDACTED if is_sensitive(str(key)) else clean(item,depth+1)
                for key,item in list(value.items())[:40]}
    if isinstance(value,list): return [clean(item,depth+1) for item in value[:40]]
    if isinstance(value,str): return value[:500]
    if value is None or type(value) in (bool,int,float): return value
    return '[UNSUPPORTED_TYPE]'

def format_event(event):
    if not isinstance(event,dict): raise ValueError('structured_event_required')
    selected={key:clean(value) for key,value in event.items() if key in ALLOWED and key!='url'}
    if 'url' in event: selected['url']=safe_url(event['url'])
    return json.dumps(selected,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n'

def write_event(stream,event):
    line=format_event(event);stream.write(line);return line

if __name__=='__main__':
    import io
    stream=io.StringIO()
    write_event(stream,{'event':'login\r\nforged','request_id':'demo-1',
                       'url':'https://user:private@example.test/path?access_token=SYNTHETIC_SECRET&page=2#private',
                       'details':{'Authorization':'Bearer SYNTHETIC_SECRET','nested':[{'api-key':'SYNTHETIC_SECRET'}]},
                       'raw_body':'SYNTHETIC_SECRET'})
    output=stream.getvalue()
    print(output,end='')
    print(json.dumps({'secret_present': 'SYNTHETIC_SECRET' in output,'physical_log_lines':len(output.splitlines()),'raw_body_retained':'raw_body' in output}))
