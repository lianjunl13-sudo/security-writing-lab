import io,json,unittest
from urllib.parse import parse_qs,urlsplit
import experiment as e
class Tests(unittest.TestCase):
 def test_secrets_redacted_before_stream_receives_bytes(self):
  class InspectingStream:
   def write(self,line):
    if 'SYNTHETIC_SECRET' in line:raise AssertionError('secret reached sink')
  e.write_event(InspectingStream(),{'event':'login','details':{'Authorization':'SYNTHETIC_SECRET','nested':[{'api-key':'SYNTHETIC_SECRET'}]},'raw_body':'SYNTHETIC_SECRET'})
 def test_url_query_duplicates_userinfo_and_fragment(self):
  value=e.safe_url('https://user:SYNTHETIC_SECRET@example.test/a?token=one&token=two&page=1#SYNTHETIC_SECRET')
  self.assertNotIn('SYNTHETIC_SECRET',value);self.assertNotIn('user:',value)
  self.assertEqual(parse_qs(urlsplit(value).query)['token'],[e.REDACTED,e.REDACTED]);self.assertEqual(parse_qs(urlsplit(value).query)['page'],['1'])
 def test_actual_crlf_is_one_physical_json_line(self):
  line=e.format_event({'event':'login\r\nFAKE_EVENT','request_id':'demo'})
  self.assertEqual(len(line.splitlines()),1);self.assertEqual(json.loads(line)['event'],'login\r\nFAKE_EVENT')
 def test_unknown_top_level_fields_dropped(self):self.assertNotIn('raw_body',e.format_event({'raw_body':'private','event':'x'}))
 def test_normalized_sensitive_keys(self):
  output=e.format_event({'details':{'ACCESS-TOKEN':'secret','api_key':'secret','Password':'secret'}})
  self.assertNotIn('secret',output);self.assertEqual(output.count(e.REDACTED),3)
 def test_depth_limit(self):
  value={'x':{'x':{'x':{'x':{'x':{'x':{'password':'secret'}}}}}}}
  output=e.format_event({'details':value});self.assertIn('DEPTH_LIMIT',output);self.assertNotIn('secret',output)
 def test_invalid_url_and_non_json_values(self):
  self.assertEqual(e.safe_url('javascript:synthetic'), '[INVALID_URL]')
  self.assertEqual(e.safe_url('https://example.test:bad/'),'[INVALID_URL]')
  self.assertIn('UNSUPPORTED_TYPE',e.format_event({'details':object()}))
 def test_explicit_limit_free_text_and_paths_not_scrubbed(self):
  output=e.format_event({'event':'unknown=visible','url':'https://example.test/path-id-visible'})
  self.assertIn('unknown=visible',output);self.assertIn('path-id-visible',output)
 def test_nonstring_url_returns_placeholder_without_attribute_error(self):
  for value in (42,None,b'https://example.test/',[],{},object()):
   with self.subTest(kind=type(value).__name__):
    self.assertEqual(e.safe_url(value),'[INVALID_URL]')
    self.assertEqual(json.loads(e.format_event({'url':value}))['url'],'[INVALID_URL]')
if __name__=='__main__':unittest.main()
