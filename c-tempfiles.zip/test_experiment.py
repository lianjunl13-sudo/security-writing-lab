import os
from pathlib import Path
import tempfile
import unittest
import experiment as app


class BoundaryTests(unittest.TestCase):
    def setUp(self): self.directory = tempfile.TemporaryDirectory(); self.root = Path(self.directory.name)
    def tearDown(self): self.directory.cleanup()
    def test_normal_cleanup(self):
        self.assertTrue(app.stage(b'hello',self.root)['same_bytes']); self.assertEqual(list(self.root.iterdir()),[])
    def test_empty_content(self):
        self.assertTrue(app.stage(b'',self.root)['same_bytes']); self.assertEqual(list(self.root.iterdir()),[])
    def test_private_mode(self):
        mode = int(app.stage(b'hello',self.root)['mode'],8)
        self.assertEqual(mode & 0o077,0)
    def test_error_cleanup(self):
        with self.assertRaises(OSError): app.stage(b'hello',self.root,fail=True)
        self.assertEqual(list(self.root.iterdir()),[])
    def test_existing_predictable_symlink_unused(self):
        target=self.root/'sentinel'; target.write_bytes(b'unchanged')
        (self.root/'pending-fixed.tmp').symlink_to(target)
        result=app.stage(b'new',self.root)
        self.assertNotEqual(result['name'],'pending-fixed.tmp'); self.assertEqual(target.read_bytes(),b'unchanged')
    def test_sample_names_differ(self):
        names = [app.stage(b'x',self.root)['name'] for _ in range(20)]
        self.assertEqual(len(set(names)),20)
    def test_size_and_type(self):
        self.assertTrue(app.stage(b'a'*1024,self.root)['same_bytes'])
        for payload in [b'a'*1025,'text',None]:
            with self.subTest(kind=type(payload)),self.assertRaises(ValueError): app.stage(payload,self.root)
        self.assertEqual(list(self.root.iterdir()),[])


if __name__ == '__main__': unittest.main()
