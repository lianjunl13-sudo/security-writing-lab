"""Local temporary staging; caller supplies a trusted service-owned directory."""
import json
import os
from pathlib import Path
import tempfile


def stage(payload, directory, fail=False):
    if type(payload) is not bytes or len(payload) > 1024: raise ValueError('invalid_payload')
    fd, name = tempfile.mkstemp(prefix='pending-', suffix='.tmp', dir=directory)
    try:
        # Keep the descriptor from atomic creation. Never reopen by pathname.
        with os.fdopen(fd, 'w+b') as output:
            mode = os.fstat(output.fileno()).st_mode & 0o777
            output.write(payload); output.flush(); os.fsync(output.fileno())
            if fail: raise OSError('synthetic_write_failure')
            output.seek(0)
            content = output.read()
        return {'name':Path(name).name,'mode':oct(mode),'same_bytes':content == payload}
    finally:
        os.unlink(name)


def main():
    with tempfile.TemporaryDirectory(prefix='staging-demo-') as directory:
        ok = stage(b'synthetic draft',directory)
        try: stage(b'synthetic draft',directory,fail=True)
        except OSError: failure = 'raised_and_cleaned'
        print(json.dumps({'stage':{k:v for k,v in ok.items() if k != 'name'},
                          'failure':failure,'remaining_files':len(list(Path(directory).iterdir()))},indent=2))


if __name__ == '__main__': main()
