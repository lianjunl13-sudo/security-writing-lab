"""Versioned PBKDF2 record upgrade. Counts are local experiment values."""
import hashlib,hmac,json,re,secrets,time
TARGET=200000
MIN_ITERATIONS=1000
MAX_ITERATIONS=1000000

class InvalidRecord(ValueError): pass

def password_bytes(password):
    if not isinstance(password,str) or len(password)>1024: raise ValueError('password_length')
    data=password.encode('utf-8')
    if not data or len(data)>1024: raise ValueError('password_bytes')
    return data

def make_record(password,iterations=TARGET,salt=None):
    if type(iterations) is not int or not MIN_ITERATIONS<=iterations<=MAX_ITERATIONS: raise InvalidRecord('iteration_range')
    data=password_bytes(password);salt=secrets.token_bytes(16) if salt is None else salt
    if not isinstance(salt,bytes) or len(salt)!=16: raise InvalidRecord('salt_length')
    digest=hashlib.pbkdf2_hmac('sha256',data,salt,iterations,dklen=32)
    return f'v1$pbkdf2_sha256${iterations}${salt.hex()}${digest.hex()}'

def parse_record(record):
    if not isinstance(record,str) or len(record)>180: raise InvalidRecord('record_size')
    match=re.fullmatch(r'v1\$pbkdf2_sha256\$([1-9][0-9]{0,6})\$([0-9a-f]{32})\$([0-9a-f]{64})',record)
    if not match: raise InvalidRecord('record_format')
    iterations=int(match[1])
    if not MIN_ITERATIONS<=iterations<=MAX_ITERATIONS: raise InvalidRecord('iteration_range')
    return iterations,bytes.fromhex(match[2]),bytes.fromhex(match[3])

def verify_and_upgrade(password,record):
    iterations,salt,expected=parse_record(record)
    actual=hashlib.pbkdf2_hmac('sha256',password_bytes(password),salt,iterations,dklen=32)
    if not hmac.compare_digest(actual,expected): return False,None
    return True,make_record(password) if iterations<TARGET else None

if __name__=='__main__':
    password='synthetic-password-仅用于测试'
    old=make_record(password,50000)
    start=time.perf_counter();ok,new=verify_and_upgrade(password,old);elapsed=time.perf_counter()-start
    print(json.dumps({'authenticated':ok,'old_iterations':parse_record(old)[0],
                      'upgraded_iterations':parse_record(new)[0],'new_salt':parse_record(old)[1]!=parse_record(new)[1],
                      'local_upgrade_ms':round(elapsed*1000,2)},ensure_ascii=False))
    print('wrong_password='+json.dumps(verify_and_upgrade('incorrect',old)))
