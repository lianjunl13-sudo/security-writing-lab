import unittest
from unittest.mock import patch
import experiment as e
class Tests(unittest.TestCase):
 def test_correct_password_upgrades_old_record(self):
  old=e.make_record('synthetic',50000);ok,new=e.verify_and_upgrade('synthetic',old)
  self.assertTrue(ok);self.assertEqual(e.parse_record(new)[0],e.TARGET);self.assertNotEqual(e.parse_record(old)[1],e.parse_record(new)[1])
 def test_wrong_password_never_upgrades(self):self.assertEqual(e.verify_and_upgrade('wrong',e.make_record('correct',1000)),(False,None))
 def test_current_record_needs_no_upgrade(self):self.assertEqual(e.verify_and_upgrade('synthetic',e.make_record('synthetic')),(True,None))
 def test_stronger_record_not_downgraded(self):self.assertEqual(e.verify_and_upgrade('synthetic',e.make_record('synthetic',e.TARGET+1)),(True,None))
 def test_random_salts_produce_different_records(self):self.assertNotEqual(e.make_record('same',1000),e.make_record('same',1000))
 def test_bad_or_expensive_record_rejected_before_kdf(self):
  with patch.object(e.hashlib,'pbkdf2_hmac',side_effect=AssertionError('must not run')):
   for record in ('v1$pbkdf2_sha256$9999999$'+'00'*16+'$'+'00'*32,'x'*181,'v2$unknown$1$x$y'):
    with self.subTest(record=record[:25]),self.assertRaises(e.InvalidRecord):e.verify_and_upgrade('x',record)
 def test_utf8_boundary_and_empty_password(self):
  with self.assertRaises(ValueError):e.make_record('中'*342,1000)
  with self.assertRaises(ValueError):e.make_record('',1000)
  record=e.make_record('中'*341,1000);self.assertTrue(e.verify_and_upgrade('中'*341,record)[0])
 def test_unicode_is_not_silently_normalized(self):
  record=e.make_record('é',1000);self.assertEqual(e.verify_and_upgrade('e\u0301',record),(False,None))
if __name__=='__main__':unittest.main()
