# Local synthetic experiment: cors-credential-origin

Original local defensive demonstration and tests, produced with AI assistance. No production data, login credentials or persistent private keys. Not a production security component.

Python 3.12; original run environment and timestamps in evidence/run.json.

```sh
python3 -B -m unittest -v test_experiment.py
python3 -B experiment.py
```

Scope: 凭据CORS的精确来源/true字节值、合并Vary与用户缓存策略；明确不同于CSRF

Limits:
- 仅响应头策略函数，无真实浏览器/服务器/代理部署
- CORS约束浏览器响应共享，不证明业务请求未执行或身份权限正确
- 需接入层统一重复Origin及双层CORS头；现有Vary为可信配置

Evidence is an original local run, not a guarantee on another platform. No article or downloaded third-party source text is included.
