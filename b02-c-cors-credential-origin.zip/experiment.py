"""CORS response-header contract only; not CSRF prevention or authentication."""
import json
import re

ORIGINS=frozenset({'https://console.example','https://admin.example'})
METHODS=frozenset({'POST','GET'})
HEADERS=frozenset({'content-type','x-csrf-token'})


def vary(existing,*names):
    values=[x.strip() for x in existing.split(',') if x.strip()]
    if '*' in values:return '*'
    for name in names:
        if name.lower() not in [x.lower() for x in values]:values.append(name)
    return ', '.join(values)


def response_headers(origin,existing_vary='Accept-Encoding'):
    result={'Vary':vary(existing_vary,'Origin'),'Cache-Control':'private, no-store'}
    if type(origin) is str and origin in ORIGINS:
        result.update({'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Credentials':'true'})
    return result


def preflight(origin,method,requested_headers='',existing_vary='Accept-Encoding'):
    result={'Vary':vary(existing_vary,'Origin','Access-Control-Request-Method','Access-Control-Request-Headers'),
            'Cache-Control':'private, no-store'}
    if type(origin) is not str or origin not in ORIGINS or type(method) is not str or method not in METHODS:
        return 403,result
    if type(requested_headers) is not str or len(requested_headers)>256:return 403,result
    if any(ord(c)<32 or ord(c)>126 for c in requested_headers):return 403,result
    fields=[x.strip().lower() for x in requested_headers.split(',')] if requested_headers else []
    if any(not re.fullmatch(r'[a-z0-9-]+',x) or x not in HEADERS for x in fields):return 403,result
    result.update({'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Credentials':'true',
                   'Access-Control-Allow-Methods':method})
    if fields:result['Access-Control-Allow-Headers']=', '.join(sorted(set(fields)))
    return 204,result


def main():
    result={}
    for origin in ['https://console.example','https://console.example.attacker.test','null']:
        result[origin]=response_headers(origin)
    status,headers=preflight('https://console.example','POST','Content-Type, X-CSRF-Token')
    result['allowed_preflight']={'status':status,'headers':headers}
    status,headers=preflight('https://console.example','DELETE','Content-Type')
    result['denied_preflight']={'status':status,'headers':headers}
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
