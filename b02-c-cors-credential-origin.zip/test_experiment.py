import unittest
import experiment as app


class CORSContractTests(unittest.TestCase):
    def test_exact_allowed_origin(self):
        headers=app.response_headers('https://console.example')
        self.assertEqual(headers['Access-Control-Allow-Origin'],'https://console.example')
        self.assertEqual(headers['Access-Control-Allow-Credentials'],'true')
    def test_origin_lookalikes_and_null(self):
        for origin in ['https://console.example.other.test','http://console.example','https://console.example:444','https://console.example/','null',None,1]:
            with self.subTest(origin=origin):self.assertNotIn('Access-Control-Allow-Origin',app.response_headers(origin))
    def test_vary_on_allowed_and_denied(self):
        for origin in ['https://console.example','https://other.test',None]:
            self.assertEqual(app.response_headers(origin)['Vary'],'Accept-Encoding, Origin')
    def test_existing_vary_preserved(self):
        self.assertEqual(app.response_headers('x','origin, Accept-Language')['Vary'],'origin, Accept-Language')
        self.assertEqual(app.response_headers('x','*')['Vary'],'*')
    def test_allowed_preflight(self):
        status,headers=app.preflight('https://console.example','POST','X-CSRF-Token, Content-Type')
        self.assertEqual(status,204);self.assertEqual(headers['Access-Control-Allow-Headers'],'content-type, x-csrf-token')
        self.assertEqual(headers['Access-Control-Allow-Methods'],'POST')
    def test_denied_preflight(self):
        for method,headers in [('DELETE',''),('POST','Authorization'),('POST','Content-Type,'),('POST','x-csrf-token\r\nInjected: true'),('POST','\r\nContent-Type\r\n'),('POST','Content-Type\x7f'),('POST','\x85Content-Type'),('POST',None)]:
            with self.subTest(method=method,headers=headers):
                status,result=app.preflight('https://console.example',method,headers)
                self.assertEqual(status,403);self.assertNotIn('Access-Control-Allow-Origin',result)
    def test_preflight_vary_dimensions(self):
        status,headers=app.preflight('https://other.test','POST')
        self.assertEqual(status,403)
        for name in ['Origin','Access-Control-Request-Method','Access-Control-Request-Headers']:self.assertIn(name,headers['Vary'])
    def test_no_wildcards_and_private_response(self):
        for origin in app.ORIGINS:
            headers=app.response_headers(origin)
            self.assertNotIn('*',headers.values());self.assertEqual(headers['Cache-Control'],'private, no-store')


if __name__=='__main__':unittest.main()
