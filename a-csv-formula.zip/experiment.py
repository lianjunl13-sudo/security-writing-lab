"""CSV export for human spreadsheet viewing, with a deliberately narrow type policy."""
import csv,io,math
class Rejected(ValueError):pass

def cell(value):
    if value is None:return ''
    if type(value) is bool:return 'TRUE' if value else 'FALSE'
    if type(value) is int:
        if abs(value)>10**15-1:raise Rejected('numeric precision budget')
        return str(value)
    if type(value) is float:
        if not math.isfinite(value):raise Rejected('non-finite number')
        return str(value)
    if type(value) is not str:raise Rejected('unsupported value type')
    if len(value)>10000:raise Rejected('text budget')
    # Strip whitespace for detection only; retain original display text.
    probe=value.lstrip()
    if probe.startswith(('=','+','-','@')) or value.startswith(('\t','\r','\n','\ufeff','\u200b')):
        return "'"+value
    return value

def export(rows):
    out=io.StringIO(newline='');writer=csv.writer(out,quoting=csv.QUOTE_ALL,lineterminator='\r\n')
    for row in rows:writer.writerow([cell(v) for v in row])
    return out.getvalue()

if __name__=='__main__':
    import json
    values=['=1+1','  @SUM(1,2)','-42',-42,'normal, text','line1\nline2']
    data=export([values]);parsed=next(csv.reader(io.StringIO(data,newline='')))
    print(json.dumps({'inputs':values,'parsed_export_fields':parsed,'csv_round_trip_fields':len(parsed)},ensure_ascii=False,indent=2))
