import unittest,csv,io,math
from experiment import cell,export,Rejected
class CsvTests(unittest.TestCase):
    def test_formula_prefixes(self):
        for x in ['=1+1','+1','-1','@SUM(A1)','   =2']:
            self.assertEqual(cell(x),"'"+x)
    def test_leading_controls(self):
        for x in ['\tvalue','\rvalue','\nvalue','\ufeff=1','\u200b=1']:
            self.assertEqual(cell(x),"'"+x)
    def test_signed_numeric_type(self):self.assertEqual(cell(-42),'-42');self.assertEqual(cell('-42'),"'-42")
    def test_bool_not_int(self):self.assertEqual(cell(True),'TRUE')
    def test_null(self):self.assertEqual(cell(None),'')
    def test_nonfinite(self):
        for n in [math.nan,math.inf,-math.inf]:
            with self.assertRaises(Rejected):cell(n)
    def test_unknown_object(self):
        with self.assertRaises(Rejected):cell({'formula':'=1'})
    def test_long_id_rejected_as_number(self):
        with self.assertRaises(Rejected):cell(1234567890123456)
    def test_large_id_preserved_as_text(self):self.assertEqual(cell('1234567890123456'),'1234567890123456')
    def test_csv_syntax_roundtrip(self):
        values=['a,b','"quoted"','line1\nline2','=1+1'];rows=list(csv.reader(io.StringIO(export([values]),newline='')))
        self.assertEqual(rows,[[*values[:3],"'=1+1"]])
    def test_crlf_in_field_cannot_add_record(self):
        rows=list(csv.reader(io.StringIO(export([['a\r\nb','x']]),newline='')));self.assertEqual(len(rows),1);self.assertEqual(len(rows[0]),2)
    def test_unicode_whitespace(self):self.assertEqual(cell('\u3000=2'),"'\u3000=2")
if __name__=='__main__':unittest.main(verbosity=2)
