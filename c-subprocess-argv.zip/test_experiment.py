import unittest
from unittest.mock import patch
import experiment as app


class BoundaryTests(unittest.TestCase):
    def test_normal(self): self.assertEqual(app.invoke('draft.txt'), {'name': 'draft.txt'})
    def test_option_like_is_data(self): self.assertEqual(app.invoke('--help'), {'name': '--help'})
    def test_spaces_are_one_argument(self): self.assertEqual(app.invoke('a b.txt')['name'], 'a b.txt')
    def test_shell_metacharacters_are_data(self):
        for text in ['$(echo marker)', 'a;echo marker', 'a|echo marker', '`echo marker`']:
            with self.subTest(text=text): self.assertEqual(app.invoke(text)['name'], text)
    def test_limits(self):
        for text in ['', 'a'*257, '\x00', None, 1]:
            with self.subTest(text=text), self.assertRaises(ValueError): app.invoke(text)
    def test_invocation_options(self):
        original = app.subprocess.run
        with patch.object(app.subprocess, 'run', wraps=original) as run:
            app.invoke('--version')
        args, kwargs = run.call_args
        self.assertEqual(args[0][-2:], ['--', '--version'])
        self.assertIs(kwargs['shell'], False)
        self.assertEqual(kwargs['timeout'], 2)


if __name__ == '__main__': unittest.main()
