"""Local synthetic argv experiment. Fixed executable and child; no real service."""
import argparse
import json
import subprocess
import sys

CHILD = "import argparse,json; p=argparse.ArgumentParser(); p.add_argument('name'); print(json.dumps({'name':p.parse_args().name}))"


def invoke(name):
    if type(name) is not str or not 1 <= len(name) <= 256 or '\x00' in name:
        raise ValueError('invalid_name')
    # Fixed executable/code. '--' belongs to this child's documented argparse API.
    args = [sys.executable, '-I', '-c', CHILD, '--', name]
    result = subprocess.run(args, shell=False, stdin=subprocess.DEVNULL,
                            capture_output=True, text=True, timeout=2, check=True)
    return json.loads(result.stdout)


def main():
    print(json.dumps({name: invoke(name) for name in [
        'draft.txt', '--help', 'a b.txt', '$(echo marker)', 'a;echo marker']}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
