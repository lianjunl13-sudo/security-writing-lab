import base64,hmac,json,unittest
import experiment as e
class Tests(unittest.TestCase):
 def setUp(self):
  self.key=b'local-experiment-only-32-byte-key!!';self.claims={'iss':'demo','aud':'client','exp':101,'nbf':99}
 def check(self,token,now=100):return e.verify(token,self.key,now=now,issuer='demo',audience='client')
 def test_valid_and_exact_expiry(self):
  token=e.sign(self.claims,self.key);self.assertEqual(self.check(token)['exp'],101)
  with self.assertRaisesRegex(e.InvalidToken,'expired'):self.check(token,101)
 def test_algorithm_not_selected_from_token(self):
  for alg in ('none','HS512','RS256'):
   with self.subTest(alg=alg),self.assertRaisesRegex(e.InvalidToken,'fixed_header'):self.check(e.sign(self.claims,self.key,{'alg':alg,'typ':'JWT'}))
 def test_modified_payload_cannot_keep_signature(self):
  token=e.sign(self.claims,self.key);head,body,sig=token.split('.')
  changed=e.b64(json.dumps(dict(self.claims,exp=999)).encode())
  with self.assertRaisesRegex(e.InvalidToken,'signature'):self.check(head+'.'+changed+'.'+sig)
 def test_wrong_key(self):
  with self.assertRaisesRegex(e.InvalidToken,'signature'):self.check(e.sign(self.claims,b'different-secret-key-at-least-32bytes'))
 def test_issuer_audience_nbf_and_required_exp(self):
  for change in ({'iss':'other'},{'aud':['client']},{'nbf':101},{'exp':None},{'exp':True}):
   with self.subTest(change=change),self.assertRaises(e.InvalidToken):self.check(e.sign(dict(self.claims,**change),self.key))
  claims=dict(self.claims);claims.pop('exp')
  with self.assertRaises(e.InvalidToken):self.check(e.sign(claims,self.key))
 def test_duplicate_keys_rejected_with_valid_signature(self):
  header=e.b64(b'{"alg":"HS256","typ":"JWT"}');body=e.b64(b'{"exp":101,"exp":999,"iss":"demo","aud":"client"}')
  data=(header+'.'+body).encode();token=data.decode()+'.'+e.b64(hmac.digest(self.key,data,'sha256'))
  with self.assertRaisesRegex(e.InvalidToken,'duplicate'):self.check(token)
 def test_noncanonical_and_padding_encoding_rejected(self):
  token=e.sign(self.claims,self.key)
  with self.assertRaises(e.InvalidToken):self.check(token+'=')
 def test_oversize_refused(self):
  with self.assertRaisesRegex(e.InvalidToken,'size'):self.check('x'*8193)
 def test_validly_signed_huge_exp_integer_rejected_as_invalid_token(self):
  token=e.sign(dict(self.claims,exp=10**400),self.key)
  with self.assertRaisesRegex(e.InvalidToken,'numeric_date'):self.check(token)
 def test_validly_signed_nbf_and_numeric_date_policy_bounds(self):
  for field,value in [('nbf',10**400),('exp',-1),('nbf',-1),('exp',float('inf')),('nbf',float('nan')),('exp',e.MAX_NUMERIC_DATE+1)]:
   with self.subTest(field=field,value=str(value)[:20]),self.assertRaisesRegex(e.InvalidToken,'numeric_date'):
    self.check(e.sign(dict(self.claims,**{field:value}),self.key))
if __name__=='__main__':unittest.main()
