"""Limited HS256 verification experiment, not a production JWT library."""
import base64, hashlib, hmac, json, math, re

MAX_NUMERIC_DATE = 253402300799  # Local policy: Unix seconds through year 9999.
class InvalidToken(ValueError): pass

def b64(data): return base64.urlsafe_b64encode(data).rstrip(b'=').decode('ascii')
def unb64(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_-]+',value): raise InvalidToken('base64url')
    try: data=base64.urlsafe_b64decode(value+'='*((-len(value))%4))
    except Exception: raise InvalidToken('base64url') from None
    if b64(data)!=value: raise InvalidToken('noncanonical_base64url')
    return data

def unique_pairs(items):
    out={}
    for key,value in items:
        if key in out: raise InvalidToken('duplicate_json_key')
        out[key]=value
    return out

def sign(claims,key,header=None):
    head=b64(json.dumps(header or {'alg':'HS256','typ':'JWT'},separators=(',',':')).encode())
    body=b64(json.dumps(claims,separators=(',',':')).encode())
    data=(head+'.'+body).encode()
    return head+'.'+body+'.'+b64(hmac.digest(key,data,'sha256'))

def verify(token,key,*,now,issuer,audience):
    if not isinstance(token,str) or len(token)>8192 or len(key)<32: raise InvalidToken('size_or_key')
    try:
        head,body,sig=token.split('.')
        header=json.loads(unb64(head),object_pairs_hook=unique_pairs)
        if header!={'alg':'HS256','typ':'JWT'}: raise InvalidToken('fixed_header_policy')
        supplied=unb64(sig)
        expected=hmac.digest(key,(head+'.'+body).encode('ascii'),'sha256')
        if not hmac.compare_digest(supplied,expected): raise InvalidToken('signature')
        claims=json.loads(unb64(body),object_pairs_hook=unique_pairs)
        if not isinstance(claims,dict): raise InvalidToken('claims_object')
        for name in ('exp','nbf'):
            if name not in claims: continue
            value=claims[name]
            # Do not coerce arbitrary JSON integers to float: that may overflow.
            if type(value) is int:
                valid = 0 <= value <= MAX_NUMERIC_DATE
            elif type(value) is float:
                valid = math.isfinite(value) and 0 <= value <= MAX_NUMERIC_DATE
            else:
                valid = False
            if not valid: raise InvalidToken('numeric_date')
        if 'exp' not in claims or now>=claims['exp']: raise InvalidToken('expired_or_missing_exp')
        if 'nbf' in claims and now<claims['nbf']: raise InvalidToken('not_yet_valid')
        if claims.get('iss')!=issuer or claims.get('aud')!=audience: raise InvalidToken('issuer_or_audience')
        return claims
    except InvalidToken: raise
    except (ValueError,TypeError,UnicodeError): raise InvalidToken('format') from None

if __name__=='__main__':
    key=b'local-experiment-only-32-byte-key!!'
    claims={'iss':'demo-api','aud':'demo-client','exp':101,'nbf':99,'sub':'synthetic-user'}
    token=sign(claims,key)
    print(json.dumps({'valid_at_100':verify(token,key,now=100,issuer='demo-api',audience='demo-client')['sub']},ensure_ascii=False))
    try: verify(token,key,now=101,issuer='demo-api',audience='demo-client')
    except InvalidToken as exc: print('expiry_boundary='+str(exc))
