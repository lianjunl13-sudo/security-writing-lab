"""One-time OAuth request correlation only; not a complete OAuth client."""
import hashlib
import json
import re
import secrets
import threading
import time


class Rejected(ValueError):pass


class States:
    def __init__(self,clock=time.monotonic,ttl=120,max_pending=64):
        if type(ttl) is not int or not 1<=ttl<=600 or type(max_pending) is not int or not 1<=max_pending<=1024:
            raise Rejected('configuration')
        self.clock=clock;self.ttl=ttl;self.max_pending=max_pending;self.pending={};self.lock=threading.Lock()

    def issue(self,session_id):
        """session_id is a trusted authenticated browser-session handle."""
        if type(session_id) is not str or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',session_id):raise Rejected('session')
        with self.lock:
            now=self.clock()
            self.pending={k:v for k,v in self.pending.items() if now<v[1]}
            if len(self.pending)>=self.max_pending:raise Rejected('pending_capacity')
            for _ in range(4):
                state=secrets.token_urlsafe(24);key=hashlib.sha256(state.encode()).digest()
                if key not in self.pending:break
            else:raise Rejected('random_collision')
            self.pending[key]=(session_id,now+self.ttl)
            return state

    def consume(self,session_id,state):
        if type(state) is not str or not re.fullmatch(r'[A-Za-z0-9_-]{32}',state):raise Rejected('state_shape')
        key=hashlib.sha256(state.encode()).digest()
        with self.lock:
            item=self.pending.get(key)
            if item is None:raise Rejected('unknown_or_consumed')
            if self.clock()>=item[1]:
                del self.pending[key];raise Rejected('expired')
            if type(session_id) is not str or session_id!=item[0]:raise Rejected('session_mismatch')
            del self.pending[key]
            return {'correlation':'accepted'}


def main():
    clock=[100.0];states=States(clock=lambda:clock[0],ttl=10);state=states.issue('session-A');out={}
    for label,session in [('other_session','session-B'),('matching_session','session-A'),('repeat','session-A')]:
        try:out[label]=states.consume(session,state)
        except Rejected as exc:out[label]={'rejected':str(exc)}
    state=states.issue('session-A');clock[0]=110.0
    try:states.consume('session-A',state)
    except Rejected as exc:out['exact_expiry']={'rejected':str(exc)}
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
