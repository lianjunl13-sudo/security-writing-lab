import concurrent.futures
import unittest
from unittest.mock import patch
import experiment as app


class StateContractTests(unittest.TestCase):
    def setUp(self):self.clock=[100.0];self.states=app.States(clock=lambda:self.clock[0],ttl=10)
    def test_matching_session(self):
        state=self.states.issue('a');self.assertEqual(self.states.consume('a',state),{'correlation':'accepted'})
    def test_wrong_session_does_not_burn(self):
        state=self.states.issue('a')
        with self.assertRaisesRegex(app.Rejected,'session_mismatch'):self.states.consume('b',state)
        self.states.consume('a',state)
    def test_single_consumption(self):
        state=self.states.issue('a');self.states.consume('a',state)
        with self.assertRaisesRegex(app.Rejected,'unknown_or_consumed'):self.states.consume('a',state)
    def test_expiry_boundary(self):
        state=self.states.issue('a');self.clock[0]=110
        with self.assertRaisesRegex(app.Rejected,'expired'):self.states.consume('a',state)
    def test_before_expiry(self):
        state=self.states.issue('a');self.clock[0]=109.999;self.states.consume('a',state)
    def test_unknown_and_shape(self):
        for state in ['x'*32,'',None,True,'汉'*32]:
            with self.subTest(state=state),self.assertRaises(app.Rejected):self.states.consume('a',state)
    def test_capacity_and_expired_reclamation(self):
        states=app.States(clock=lambda:self.clock[0],ttl=10,max_pending=1);states.issue('a')
        with self.assertRaisesRegex(app.Rejected,'pending_capacity'):states.issue('b')
        self.clock[0]=110;self.assertEqual(len(states.issue('b')),32)
    def test_parallel_consumption(self):
        state=self.states.issue('a')
        def attempt(_):
            try:self.states.consume('a',state);return 'accepted'
            except app.Rejected:return 'rejected'
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:results=list(pool.map(attempt,range(8)))
        self.assertEqual(results.count('accepted'),1);self.assertEqual(results.count('rejected'),7)
    def test_random_collision_cannot_replace_session(self):
        with patch.object(app.secrets,'token_urlsafe',return_value='x'*32):
            state=self.states.issue('a')
            with self.assertRaisesRegex(app.Rejected,'random_collision'):self.states.issue('b')
        self.states.consume('a',state)
    def test_restart_loses_state(self):
        state=self.states.issue('a');other=app.States(clock=lambda:self.clock[0])
        with self.assertRaises(app.Rejected):other.consume('a',state)


if __name__=='__main__':unittest.main()
