# Local synthetic experiment: oauth-state-binding

Original local defensive demonstration and tests, produced with AI assistance. No production data, login credentials or persistent private keys. Not a production security component.

Python 3.12; original run environment and timestamps in evidence/run.json.

```sh
python3 -B -m unittest -v test_experiment.py
python3 -B experiment.py
```

Scope: 仅OAuth回调请求关联：不可猜测state的会话绑定、精确到期与原子一次消费

Limits:
- 未实现OAuth完整客户端、授权码兑换、PKCE/nonce/服务器身份核对
- 内存表及进程锁不跨重启/多进程，真实存储需原子消费和统一时间
- 会话句柄来自可信宿主；错误会话不消费，成功关联后后续失败也不恢复旧state

Evidence is an original local run, not a guarantee on another platform. No article or downloaded third-party source text is included.
