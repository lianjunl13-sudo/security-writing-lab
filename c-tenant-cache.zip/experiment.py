"""Synchronous in-memory cache, with trusted host identities and synthetic data."""
import copy
from dataclasses import dataclass
import json
import threading


@dataclass(frozen=True)
class Identity:
    tenant: str
    reports: frozenset[str]


class Reports:
    def __init__(self):
        self._source={}; self._cache={}; self._lock=threading.RLock(); self.loads=0

    def put(self, tenant, report_id, text):
        """Trusted source update, not exposed to request data."""
        with self._lock:
            old=self._source.get((tenant,report_id))
            version=old[0]+1 if old else 1
            self._source[(tenant,report_id)]=(version,text)
            self._cache.pop((tenant,report_id),None)

    def get(self, identity, report_id):
        # Authentication and identity construction belong to the trusted host.
        if type(identity) is not Identity or type(report_id) is not str or report_id not in identity.reports:
            raise PermissionError('report_not_authorized')
        key=(identity.tenant,report_id)
        with self._lock:
            if key not in self._source: raise KeyError('report_missing')
            version,text=self._source[key]
            cached=self._cache.get(key)
            if cached is None or cached['version'] != version:
                self.loads+=1
                cached={'tenant':identity.tenant,'report':report_id,'version':version,'text':text}
                self._cache[key]=cached
            # Never return the mutable object stored in the cache.
            return copy.deepcopy(cached)


def main():
    reports=Reports(); reports.put('alpha','weekly','alpha synthetic'); reports.put('beta','weekly','beta synthetic')
    alice=Identity('alpha',frozenset({'weekly'})); bob=Identity('beta',frozenset({'weekly'}))
    result={'alpha':reports.get(alice,'weekly'),'beta':reports.get(bob,'weekly')}
    reports.get(alice,'weekly'); result['source_loads_after_repeat']=reports.loads
    try: reports.get(Identity('alpha',frozenset()),'weekly')
    except PermissionError: result['revoked_context']='rejected_even_with_warm_cache'
    reports.put('alpha','weekly','alpha updated'); result['after_update']=reports.get(alice,'weekly')
    print(json.dumps(result,indent=2))


if __name__ == '__main__': main()
