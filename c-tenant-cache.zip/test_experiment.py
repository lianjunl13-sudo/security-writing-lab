import concurrent.futures
import unittest
import experiment as app


class BoundaryTests(unittest.TestCase):
    def setUp(self):
        self.store=app.Reports(); self.store.put('alpha','same','alpha only'); self.store.put('beta','same','beta only')
        self.a=app.Identity('alpha',frozenset({'same'})); self.b=app.Identity('beta',frozenset({'same'}))
    def test_tenant_collision_isolated(self):
        self.assertEqual(self.store.get(self.a,'same')['text'],'alpha only')
        self.assertEqual(self.store.get(self.b,'same')['text'],'beta only')
    def test_repeat_uses_cache(self):
        self.store.get(self.a,'same'); self.store.get(self.a,'same'); self.assertEqual(self.store.loads,1)
    def test_permission_checked_before_warm_cache(self):
        self.store.get(self.a,'same')
        with self.assertRaises(PermissionError): self.store.get(app.Identity('alpha',frozenset()),'same')
    def test_mutable_return_is_copy(self):
        response=self.store.get(self.a,'same'); response['text']='modified'
        self.assertEqual(self.store.get(self.a,'same')['text'],'alpha only')
    def test_update_invalidates(self):
        self.store.get(self.a,'same'); self.store.put('alpha','same','updated')
        response=self.store.get(self.a,'same'); self.assertEqual((response['version'],response['text']),(2,'updated'))
        self.assertEqual(self.store.get(self.b,'same')['text'],'beta only')
    def test_thread_pool_tenants(self):
        identities=[self.a,self.b]*20
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results=list(pool.map(lambda identity:self.store.get(identity,'same'),identities))
        self.assertEqual([x['text'] for x in results],['alpha only','beta only']*20)
        self.assertEqual(self.store.loads,2)
    def test_missing_and_untrusted_shape(self):
        with self.assertRaises(KeyError): self.store.get(app.Identity('alpha',frozenset({'missing'})),'missing')
        with self.assertRaises(PermissionError): self.store.get({'tenant':'alpha','reports':['same']},'same')


if __name__ == '__main__': unittest.main()
