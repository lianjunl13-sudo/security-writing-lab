import unittest
import experiment as app


class CSRFSampleTests(unittest.TestCase):
    def setUp(self):
        self.service=app.Preferences();self.service.open_session('a');self.service.open_session('b')
        self.token=self.service.token_for_render('a')
    def update(self,**changes):
        kwargs={'method':'POST','origin':app.TARGET_ORIGIN,'csrf':self.token};kwargs.update(changes)
        return self.service.update('a',**kwargs)
    def test_valid_origin_token(self):self.assertEqual(self.update(),{'route':'route-B'})
    def test_cross_session_token(self):
        with self.assertRaisesRegex(app.Rejected,'token_mismatch'):self.update(csrf=self.service.token_for_render('b'))
    def test_wrong_source_no_mutation(self):
        with self.assertRaisesRegex(app.Rejected,'source_mismatch'):self.update(origin='https://app.example.other.test')
        self.assertEqual(self.service.sessions['a']['route'],'route-A')
    def test_missing_or_malformed_token(self):
        for token in [None,'',True,'x'*33,'汉'*32]:
            with self.subTest(token=token),self.assertRaises(app.Rejected):self.update(csrf=token)
    def test_missing_sources(self):
        with self.assertRaises(app.Rejected):self.update(origin=None)
    def test_referer_fallback(self):
        self.assertEqual(self.update(origin=None,referer='https://app.example:443/settings?tab=1'),{'route':'route-B'})
    def test_origin_present_never_falls_back(self):
        for origin in ['null','https://other.test','https://app.example/',1]:
            with self.subTest(origin=origin),self.assertRaises(app.Rejected):self.update(origin=origin,referer=app.TARGET_ORIGIN+'/')
    def test_referer_representation(self):
        for referer in ['https://u@app.example/','https://app.example:444/','http://app.example/','https://app.example/#fragment','\nhttps://app.example/','https://app.example\\@other/','https://app.example/path\x7f','https://app.example/path\x85','https://app.example/path\u00a0']:
            with self.subTest(referer=referer),self.assertRaises(app.Rejected):self.update(origin=None,referer=referer)
    def test_method_and_unknown_session(self):
        with self.assertRaises(app.Rejected):self.update(method='GET')
        with self.assertRaises(app.Rejected):self.service.update('missing',method='POST',origin=app.TARGET_ORIGIN,csrf=self.token)
    def test_session_token_reusable_by_policy(self):
        self.update();self.assertEqual(self.update(route='route-A'),{'route':'route-A'})


if __name__=='__main__':unittest.main()
