"""Synthetic cookie-session preference update; no HTTP server or browser."""
import hmac
import json
import re
import secrets
from urllib.parse import urlsplit

TARGET_ORIGIN='https://app.example'


class Rejected(ValueError): pass


def source_matches(origin, referer):
    if origin is not None:
        return type(origin) is str and origin == TARGET_ORIGIN
    if type(referer) is not str or len(referer)>2048 or any(c.isspace() or ord(c)<33 or 127<=ord(c)<160 for c in referer) or '\\' in referer:
        return False
    try:
        parsed=urlsplit(referer)
        return (parsed.scheme=='https' and parsed.hostname=='app.example'
                and parsed.port in (None,443) and parsed.username is None
                and parsed.password is None and not parsed.fragment)
    except ValueError:
        return False


class Preferences:
    def __init__(self): self.sessions={}

    def open_session(self, session_id):
        """Trusted host supplies an authenticated session, not arbitrary request data."""
        self.sessions[session_id]={'csrf':secrets.token_urlsafe(24),'route':'route-A'}

    def token_for_render(self, session_id):
        return self.sessions[session_id]['csrf']

    def update(self, session_id, *, method, origin=None, referer=None, csrf=None, route='route-B'):
        session=self.sessions.get(session_id)
        if session is None or method!='POST': raise Rejected('session_or_method')
        if not source_matches(origin,referer): raise Rejected('source_mismatch')
        if type(csrf) is not str or not re.fullmatch(r'[A-Za-z0-9_-]{32}',csrf): raise Rejected('token_missing_or_shape')
        if not hmac.compare_digest(session['csrf'],csrf): raise Rejected('token_mismatch')
        if route not in ('route-A','route-B'): raise Rejected('route_value')
        session['route']=route
        return {'route':route}


def main():
    service=Preferences();service.open_session('alice');service.open_session('bob')
    alice=service.token_for_render('alice');bob=service.token_for_render('bob');result={}
    cases={'valid_origin_and_token':{'origin':TARGET_ORIGIN,'csrf':alice},
      'cross_session_token':{'origin':TARGET_ORIGIN,'csrf':bob},
      'valid_token_wrong_origin':{'origin':'https://other.example','csrf':alice},
      'invalid_origin_no_fallback':{'origin':'null','referer':TARGET_ORIGIN+'/settings','csrf':alice},
      'referer_fallback':{'referer':TARGET_ORIGIN+'/settings','csrf':alice}}
    for name,kwargs in cases.items():
        try:result[name]={'accepted':service.update('alice',method='POST',**kwargs)}
        except Rejected as exc:result[name]={'rejected':str(exc)}
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
