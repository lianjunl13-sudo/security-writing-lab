# Local synthetic experiment: csrf-cookie-origin

Original local defensive demonstration and tests, produced with AI assistance. No production data, login credentials or persistent private keys. Not a production security component.

Python 3.12; original run environment and timestamps in evidence/run.json.

```sh
python3 -B -m unittest -v test_experiment.py
python3 -B experiment.py
```

Scope: Cookie会话偏好更新：同步令牌绑定与严格Origin/Referer来源合同，先校验再写入

Limits:
- 只有本地合成会话函数，无HTTP服务器/浏览器/身份认证
- 已提取单个请求头值，未验证原始重复请求头
- 会话令牌按策略可复用；未解决XSS、代理信任及完整会话管理

Evidence is an original local run, not a guarantee on another platform. No article or downloaded third-party source text is included.
