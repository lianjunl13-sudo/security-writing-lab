"""SQLite query construction: fixed identifier maps, bound values."""
import json
import sqlite3

SORTS = {'created': 'id', 'priority': 'priority', 'title': 'title'}
DIRECTIONS = {'ascending': 'ASC', 'descending': 'DESC'}


def build_query(title, sort='created', direction='ascending', limit=10):
    if type(title) is not str or len(title) > 256: raise ValueError('invalid_title')
    if type(sort) is not str or sort not in SORTS: raise ValueError('unknown_sort')
    if type(direction) is not str or direction not in DIRECTIONS: raise ValueError('unknown_direction')
    if type(limit) is not int or not 1 <= limit <= 10: raise ValueError('invalid_limit')
    # Only developer-authored constant fragments enter SQL text.
    query = ('SELECT id,title,priority FROM notes WHERE title = ? ORDER BY '
             + SORTS[sort] + ' ' + DIRECTIONS[direction] + ', id ASC LIMIT ?')
    return query, (title, limit)


def lookup(connection, title, **options):
    query, parameters = build_query(title, **options)
    return connection.execute(query, parameters).fetchall()


def database():
    connection = sqlite3.connect(':memory:')
    connection.execute('CREATE TABLE notes(id INTEGER PRIMARY KEY,title TEXT NOT NULL,priority INTEGER NOT NULL)')
    connection.executemany('INSERT INTO notes VALUES(?,?,?)', [
        (1,'draft',2), (2,'draft',9), (3,"x' OR 1=1 --",1), (4,'other',5)])
    return connection


def main():
    with database() as connection:
        result = {'priority_descending': lookup(connection,'draft',sort='priority',direction='descending'),
                  'injection_like_value': lookup(connection,"x' OR 1=1 --")}
        try: lookup(connection,'draft',sort='priority; DROP TABLE notes;--')
        except ValueError: result['unmapped_identifier'] = 'rejected'
        result['remaining_rows'] = connection.execute('SELECT COUNT(*) FROM notes').fetchone()[0]
    connection.close()
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__ == '__main__': main()
