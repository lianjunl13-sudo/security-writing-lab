import unittest
import experiment as app


class BoundaryTests(unittest.TestCase):
    def setUp(self): self.connection = app.database()
    def tearDown(self): self.connection.close()
    def test_sort_mapping(self):
        rows = app.lookup(self.connection,'draft',sort='priority',direction='descending')
        self.assertEqual([x[0] for x in rows],[2,1])
    def test_value_bound_not_interpolated(self):
        payload = "x' OR 1=1 --"
        query, params = app.build_query(payload)
        self.assertNotIn(payload,query); self.assertEqual(params,(payload,10))
        self.assertEqual([x[0] for x in app.lookup(self.connection,payload)],[3])
    def test_sort_rejected(self):
        for sort in ['priority DESC', 'priority; DROP TABLE notes', 'id', None, True]:
            with self.subTest(sort=sort),self.assertRaises(ValueError): app.lookup(self.connection,'draft',sort=sort)
    def test_direction_rejected(self):
        for direction in ['DESC','descending;--','',None]:
            with self.subTest(direction=direction),self.assertRaises(ValueError): app.lookup(self.connection,'draft',direction=direction)
    def test_limit_and_title(self):
        for limit in [0,11,True,'1']:
            with self.subTest(limit=limit),self.assertRaises(ValueError): app.lookup(self.connection,'draft',limit=limit)
        self.assertEqual(len(app.lookup(self.connection,'draft',limit=1)),1)
        with self.assertRaises(ValueError): app.lookup(self.connection,'a'*257)
    def test_no_side_effect(self):
        app.lookup(self.connection,"'; DROP TABLE notes;--")
        self.assertEqual(self.connection.execute('SELECT COUNT(*) FROM notes').fetchone()[0],4)


if __name__ == '__main__': unittest.main()
