# SQL 排序字段为什么不能和查询值共用一个参数化思路：配套本地实验

仅包含原创代码与运行证据，不含投稿正文或第三方文档。全部为本地合成测试，边界见代码。

```sh
python3 -m unittest -v test_experiment.py
python3 experiment.py
```

证据保留原执行时间和源码哈希；公开副本把本机用户目录路径替换为<local-runtime-path>。AI辅助编写，独立审阅。
