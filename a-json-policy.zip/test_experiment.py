import unittest,json
from experiment import parse_policy,Rejected
class JsonTests(unittest.TestCase):
    def policy(self,**updates):return json.dumps(dict(enabled=True,retries=2,roles=['reader'])|updates).encode()
    def reject(self,b):
        with self.assertRaises(Rejected):parse_policy(b)
    def test_valid(self):self.assertEqual(parse_policy(self.policy())['retries'],2)
    def test_duplicate_root(self):self.reject(b'{"enabled":false,"enabled":true,"retries":2,"roles":[]}')
    def test_escaped_duplicate(self):self.reject(b'{"enabled":true,"retries":1,"\\u0072etries":2,"roles":[]}')
    def test_nested_duplicate(self):self.reject(b'{"enabled":true,"retries":2,"roles":[{"x":1,"x":2}]}')
    def test_nonfinite(self):
        for token in [b'NaN',b'Infinity',b'-Infinity']:self.reject(b'{"enabled":true,"retries":'+token+b',"roles":[]}')
    def test_bool_not_count(self):self.reject(self.policy(retries=True))
    def test_float_not_count(self):self.reject(self.policy(retries=2.0))
    def test_int_not_bool(self):self.reject(self.policy(enabled=1))
    def test_range(self):
        for n in [-1,6]:self.reject(self.policy(retries=n))
    def test_unknown_or_missing_field(self):
        self.reject(self.policy(debug=True));self.reject(b'{"enabled":true,"retries":2}')
    def test_duplicate_roles(self):self.reject(self.policy(roles=['reader','reader']))
    def test_bad_role_or_shape(self):
        for roles in [['admin'],{},[1],['reader','writer','auditor','reader']]:self.reject(self.policy(roles=roles))
    def test_encoding_or_bom(self):
        for data in [b'\xff',b'\xef\xbb\xbf'+self.policy()]:self.reject(data)
    def test_trailing_or_root_type(self):
        for data in [self.policy()+b'{}',b'[]',b'null']:self.reject(data)
    def test_input_size(self):self.reject(b' '*4097)
if __name__=='__main__':unittest.main(verbosity=2)
