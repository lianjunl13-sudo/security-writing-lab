"""Strict small JSON policy object; does not attempt general JSON resource control."""
import json
class Rejected(ValueError):pass

def pairs(items):
    result={}
    for key,value in items:
        if key in result:raise Rejected('duplicate object key')
        result[key]=value
    return result

def reject_constant(value):raise Rejected('non-finite numeric literal')

def parse_policy(data):
    if type(data) is not bytes or len(data)>4096:raise Rejected('input type or size')
    try:obj=json.loads(data.decode('utf-8'),object_pairs_hook=pairs,parse_constant=reject_constant)
    except (UnicodeError,json.JSONDecodeError,RecursionError):raise Rejected('invalid JSON') from None
    if type(obj) is not dict or set(obj)!={'enabled','retries','roles'}:raise Rejected('exact fields')
    if type(obj['enabled']) is not bool:raise Rejected('enabled type')
    if type(obj['retries']) is not int or not 0<=obj['retries']<=5:raise Rejected('retries type or range')
    roles=obj['roles']
    if type(roles) is not list or len(roles)>3 or any(type(r) is not str or r not in ('reader','writer','auditor') for r in roles) or len(set(roles))!=len(roles):raise Rejected('roles')
    return obj

if __name__=='__main__':
    import json
    samples={'normal':b'{"enabled":true,"retries":2,"roles":["reader"]}',
     'duplicate':b'{"enabled":false,"enabled":true,"retries":2,"roles":[]}',
     'bool_as_count':b'{"enabled":true,"retries":true,"roles":[]}',
     'nan':b'{"enabled":true,"retries":NaN,"roles":[]}'}
    results={}
    for name,data in samples.items():
        try:results[name]={'status':'accepted','value':parse_policy(data)}
        except Rejected as e:results[name]={'status':'rejected','reason':str(e)}
    print(json.dumps(results,ensure_ascii=False,indent=2))
