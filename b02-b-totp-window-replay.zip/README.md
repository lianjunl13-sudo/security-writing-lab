# totp-window-replay: reproducible synthetic experiment

Original defensive engineering code and tests. No article body or third-party source documents included.

## Run

Python 3.12 was used for the recorded run. In this folder:

    python -B -m unittest -v test_experiment.py
    python -B experiment.py

## Evidence and boundaries

Observed tests/demos used only synthetic inputs. evidence/run.json redacts local path strings only; timestamps, environment versions, code hashes and stdout/stderr hashes are retained.

- 公开 RFC 种子与合成设备状态；教学实现，不可作为生产 MFA。
- 未实现设备注册、密钥存储、限速、恢复、交易绑定或抗钓鱼。
- 对称 ±1 时间步是实验策略；接受未来步后会拒绝较旧或相同步。
- 时间步水位须跨实例持久化，恢复旧数据库可能重新接受已用步。
- 水位约束时间步，并非永久封禁重复出现的数字串。

AI-assisted original code; local tests actually executed. No production deployment or universal security certification is claimed.
