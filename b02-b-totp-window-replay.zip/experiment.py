"""RFC6238 teaching implementation and SQLite step watermark; not production MFA."""
import hashlib,hmac,json,re,sqlite3,struct,tempfile
from pathlib import Path
from contextlib import contextmanager
@contextmanager
def connection(*args, **kwargs):
    db=sqlite3.connect(*args, **kwargs)
    try:
        with db:
            yield db
    finally:
        db.close()

KEYS={'sha1':b'12345678901234567890','sha256':b'12345678901234567890123456789012',
      'sha512':b'1234567890123456789012345678901234567890123456789012345678901234'}
VECTORS=[(59,'94287082','46119246','90693936'),(1111111109,'07081804','68084774','25091201'),
 (1111111111,'14050471','67062674','99943326'),(1234567890,'89005924','91819424','93441116'),
 (2000000000,'69279037','90698825','38618901'),(20000000000,'65353130','77737706','47863826')]
class InvalidOTP(ValueError):pass

def code_at_step(secret,step,algorithm='sha1'):
    if type(secret) is not bytes or len(secret)<16 or algorithm not in KEYS:raise ValueError('key_or_algorithm')
    if type(step) is not int or not 0<=step<2**64:raise ValueError('step')
    digest=hmac.digest(secret,struct.pack('>Q',step),algorithm);offset=digest[-1]&15
    number=struct.unpack('>I',digest[offset:offset+4])[0]&0x7fffffff
    return str(number%10**8).zfill(8)

def totp(secret,now,algorithm='sha1'):
    if type(now) is not int or not 0<=now<30*(2**64):raise ValueError('clock')
    return code_at_step(secret,now//30,algorithm)

def initialize(path):
    with connection(path) as db:
        db.execute('CREATE TABLE state(credential_id TEXT PRIMARY KEY,last_step INTEGER NOT NULL)')
        db.execute("INSERT INTO state VALUES('synthetic-device',-1)")

def verify_once(path,credential_id,secret,code,*,now,window=1,algorithm='sha1'):
    if type(code) is not str or not re.fullmatch(r'[0-9]{8}',code):raise InvalidOTP('invalid_otp')
    if type(window) is not int or not 0<=window<=1:raise ValueError('window')
    if type(now) is not int or not 0<=now<=253402300799:raise ValueError('clock')
    current=now//30
    matches=[step for step in range(max(0,current-window),current+window+1)
             if hmac.compare_digest(code_at_step(secret,step,algorithm),code)]
    if not matches:raise InvalidOTP('invalid_otp')
    matched=max(matches)
    with connection(path,timeout=5,isolation_level=None) as db:
        try:
            db.execute('BEGIN IMMEDIATE')
            changed=db.execute('UPDATE state SET last_step=? WHERE credential_id=? AND last_step<?',(matched,credential_id,matched)).rowcount
            if changed!=1:raise InvalidOTP('invalid_otp')
            db.execute('COMMIT');return matched
        except Exception:
            if db.in_transaction:db.execute('ROLLBACK')
            raise

if __name__=='__main__':
    passed=sum(totp(KEYS[alg],row[0],alg)==row[index+1] for row in VECTORS for index,alg in enumerate(KEYS))
    with tempfile.TemporaryDirectory() as temp:
        path=Path(temp)/'otp.db';initialize(path);secret=KEYS['sha1'];code=totp(secret,59)
        result={'official_vector_matches':passed,'official_vector_cases':18,
                'accepted_previous_step':verify_once(path,'synthetic-device',secret,code,now=60)}
        try:verify_once(path,'synthetic-device',secret,code,now=60)
        except InvalidOTP:result['same_step_replay']='rejected'
        print(json.dumps(result))
