import tempfile,threading,unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import experiment as e

class TOTPTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'state.db';e.initialize(self.path);self.key=e.KEYS['sha1']
    def verify(self,code,now=90,**kw):return e.verify_once(self.path,'synthetic-device',self.key,code,now=now,**kw)
    def watermark(self):
        with e.connection(self.path) as db:return db.execute('SELECT last_step FROM state').fetchone()[0]
    def test_all_eighteen_rfc_vectors(self):
        for row in e.VECTORS:
            for index,alg in enumerate(e.KEYS):
                with self.subTest(time=row[0],algorithm=alg):self.assertEqual(e.totp(e.KEYS[alg],row[0],alg),row[index+1])
    def test_boundary_at_thirty_seconds(self):
        self.assertEqual(e.totp(self.key,29),e.code_at_step(self.key,0))
        self.assertEqual(e.totp(self.key,30),e.code_at_step(self.key,1))
    def test_previous_step_allowed_once(self):
        code=e.totp(self.key,59);self.assertEqual(self.verify(code,now=60),1)
        with self.assertRaises(e.InvalidOTP):self.verify(code,now=60)
    def test_zero_window_rejects_previous_without_advancing(self):
        with self.assertRaises(e.InvalidOTP):self.verify(e.totp(self.key,59),now=60,window=0)
        self.assertEqual(self.watermark(),-1)
        self.assertEqual(self.verify(e.totp(self.key,60),now=60,window=0),2)
    def test_outside_window_and_invalid_codes_leave_state(self):
        for code in [e.code_at_step(self.key,1),e.code_at_step(self.key,5),'0000000','000000000','１２３４５６７８',None]:
            with self.subTest(code=code),self.assertRaises(e.InvalidOTP):self.verify(code,now=90)
        self.assertEqual(self.watermark(),-1)
    def test_newer_step_blocks_older_even_inside_window(self):
        self.assertEqual(self.verify(e.code_at_step(self.key,3)),3)
        with self.assertRaises(e.InvalidOTP):self.verify(e.code_at_step(self.key,2))
    def test_future_step_uses_high_watermark(self):
        self.assertEqual(self.verify(e.code_at_step(self.key,4)),4)
        with self.assertRaises(e.InvalidOTP):self.verify(e.code_at_step(self.key,3))
        with self.assertRaises(e.InvalidOTP):self.verify(e.code_at_step(self.key,4),now=120)
        self.assertEqual(self.verify(e.code_at_step(self.key,5),now=150),5)
    def test_unknown_credential_cannot_create_state(self):
        with self.assertRaises(e.InvalidOTP):e.verify_once(self.path,'missing',self.key,e.totp(self.key,90),now=90)
        self.assertEqual(self.watermark(),-1)
    def test_concurrent_same_step_one_success(self):
        barrier=threading.Barrier(10);code=e.totp(self.key,90)
        def worker(_):
            barrier.wait()
            try:self.verify(code);return 1
            except e.InvalidOTP:return 0
        with ThreadPoolExecutor(max_workers=10) as pool:self.assertEqual(sum(pool.map(worker,range(10))),1)
        self.assertEqual(self.watermark(),3)
    def test_wrong_shared_secret_does_not_advance_state(self):
        with self.assertRaises(e.InvalidOTP):e.verify_once(self.path,'synthetic-device',b'x'*20,e.totp(self.key,90),now=90)
        self.assertEqual(self.watermark(),-1)
    def test_algorithm_key_clock_and_window_bounds(self):
        for kwargs in [{'window':2},{'window':True},{'now':-1},{'now':True},{'algorithm':'md5'}]:
            args={'now':90};args.update(kwargs)
            with self.subTest(kwargs=kwargs),self.assertRaises(ValueError):e.verify_once(self.path,'synthetic-device',self.key,e.totp(self.key,90),**args)
        for step in [-1,2**64,True,0.5]:
            with self.subTest(step=step),self.assertRaises(ValueError):e.code_at_step(self.key,step)
        with self.assertRaises(ValueError):e.code_at_step(b'short',1)
        self.assertEqual(len(e.code_at_step(self.key,2**64-1)),8)
if __name__=='__main__':unittest.main(verbosity=2)
