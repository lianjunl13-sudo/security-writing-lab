import unittest,gzip
from experiment import decode,Rejected
class GzipTests(unittest.TestCase):
    def zip(self,v):return gzip.compress(v,mtime=0)
    def test_normal(self):self.assertEqual(decode([self.zip(b'hello')]),b'hello')
    def test_empty_payload(self):self.assertEqual(decode([self.zip(b'')]),b'')
    def test_small_chunks(self):
        c=self.zip(b'ab'*1000);self.assertEqual(decode([c[i:i+1] for i in range(len(c))]),b'ab'*1000)
    def test_exact_output_limit(self):self.assertEqual(decode([self.zip(b'a'*4096)],max_output=4096),b'a'*4096)
    def test_output_plus_one(self):
        with self.assertRaisesRegex(Rejected,'output budget'):decode([self.zip(b'a'*4097)],max_output=4096)
    def test_high_expansion(self):
        with self.assertRaisesRegex(Rejected,'output budget'):decode([self.zip(b'a'*100000)],max_output=1000)
    def test_input_limit(self):
        c=self.zip(b'a')
        with self.assertRaisesRegex(Rejected,'input budget'):decode([c],max_input=len(c)-1)
    def test_truncated(self):
        with self.assertRaisesRegex(Rejected,'truncated'):decode([self.zip(b'ok')[:-1]])
    def test_checksum(self):
        c=bytearray(self.zip(b'ok'));c[-8]^=1
        with self.assertRaisesRegex(Rejected,'checksum'):decode([bytes(c)])
    def test_trailing_same_chunk(self):
        with self.assertRaisesRegex(Rejected,'trailing'):decode([self.zip(b'ok')+b'extra'])
    def test_trailing_next_chunk(self):
        with self.assertRaisesRegex(Rejected,'trailing'):decode([self.zip(b'ok'),b'extra'])
    def test_two_members(self):
        with self.assertRaisesRegex(Rejected,'additional'):decode([self.zip(b'a')+self.zip(b'b')])
    def test_oversized_chunk(self):
        with self.assertRaisesRegex(Rejected,'chunk'):decode([b'x'*8193])
    def test_invalid_type(self):
        with self.assertRaises(Rejected):decode(['text'])
if __name__=='__main__':unittest.main(verbosity=2)
