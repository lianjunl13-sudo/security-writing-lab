"""Single-member gzip decoding with a bounded temporary output, no network."""
import zlib,tempfile
class Rejected(ValueError):pass

def decode(chunks,max_input=65536,max_output=131072):
    if type(max_input) is not int or type(max_output) is not int or min(max_input,max_output)<1:raise Rejected('limits')
    decoder=zlib.decompressobj(16+zlib.MAX_WBITS)
    consumed=produced=0
    output=tempfile.SpooledTemporaryFile(max_size=4096,mode='w+b')
    try:
        for chunk in chunks:
            if type(chunk) is not bytes or len(chunk)>8192:raise Rejected('chunk type or size')
            consumed+=len(chunk)
            if consumed>max_input:raise Rejected('input budget')
            if decoder.eof and chunk:raise Rejected('trailing data or additional member')
            pending=chunk
            while pending:
                remaining=max_output-produced
                block=decoder.decompress(pending,min(4096,remaining+1))
                produced+=len(block)
                if produced>max_output:raise Rejected('output budget')
                output.write(block)
                if decoder.unused_data:raise Rejected('trailing data or additional member')
                pending=decoder.unconsumed_tail
        if not decoder.eof:raise Rejected('truncated stream')
        output.seek(0)
        return output.read()  # At most max_output bytes; caller may instead consume the file.
    except zlib.error:raise Rejected('invalid gzip or checksum') from None
    finally:output.close()

if __name__=='__main__':
    import gzip,json
    results={}
    for name,raw in [('small',b'local synthetic text'),('high_expansion',b'A'*100000)]:
        compressed=gzip.compress(raw,mtime=0)
        try:out=decode([compressed],max_output=4096);results[name]={'status':'decoded','compressed_bytes':len(compressed),'output_bytes':len(out)}
        except Rejected as e:results[name]={'status':'rejected','reason':str(e),'compressed_bytes':len(compressed),'original_bytes':len(raw)}
    print(json.dumps(results,ensure_ascii=False,indent=2))
