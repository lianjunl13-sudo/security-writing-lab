"""Single-database transactional idempotency under concurrent requests."""
import hashlib,json,sqlite3,tempfile,threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

class Conflict(ValueError): pass

def initialize(path):
    with sqlite3.connect(path) as db:
        db.executescript("CREATE TABLE stock(sku TEXT PRIMARY KEY,quantity INTEGER NOT NULL);"
                         "INSERT INTO stock VALUES('book',100);"
                         "CREATE TABLE receipts(request_key TEXT PRIMARY KEY,payload_hash TEXT NOT NULL,receipt TEXT NOT NULL);")

def purchase(path,request_key,quantity,*,crash=False):
    if type(quantity) is not int or not 1<=quantity<=10: raise ValueError('quantity')
    digest=hashlib.sha256(json.dumps({'sku':'book','quantity':quantity},sort_keys=True).encode()).hexdigest()
    db=sqlite3.connect(path,timeout=5,isolation_level=None)
    try:
        db.execute('BEGIN IMMEDIATE')
        row=db.execute('SELECT payload_hash,receipt FROM receipts WHERE request_key=?',(request_key,)).fetchone()
        if row:
            if row[0]!=digest: raise Conflict('key_reused_with_different_payload')
            db.execute('COMMIT'); return row[1]
        changed=db.execute('UPDATE stock SET quantity=quantity-? WHERE sku=? AND quantity>=?',(quantity,'book',quantity)).rowcount
        if changed!=1: raise ValueError('insufficient_stock')
        if crash: raise RuntimeError('simulated_failure_before_receipt')
        receipt='receipt-'+hashlib.sha256(request_key.encode()).hexdigest()[:16]
        db.execute('INSERT INTO receipts VALUES(?,?,?)',(request_key,digest,receipt))
        db.execute('COMMIT'); return receipt
    except Exception:
        if db.in_transaction: db.execute('ROLLBACK')
        raise
    finally: db.close()

def snapshot(path):
    with sqlite3.connect(path) as db:
        return {'stock':db.execute('SELECT quantity FROM stock').fetchone()[0],
                'receipt_rows':db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0]}

def concurrent_run(path,workers=12):
    barrier=threading.Barrier(workers)
    def worker(_): barrier.wait(); return purchase(path,'same-request',1)
    with ThreadPoolExecutor(max_workers=workers) as pool: results=list(pool.map(worker,range(workers)))
    return {'requests':workers,'unique_receipts':len(set(results)),**snapshot(path)}

if __name__=='__main__':
    with tempfile.TemporaryDirectory() as temp:
        path=Path(temp)/'orders.db';initialize(path)
        print(json.dumps(concurrent_run(path),ensure_ascii=False))
        try: purchase(path,'same-request',2)
        except Conflict as exc: print('payload_conflict='+str(exc))
        try: purchase(path,'crash-request',1,crash=True)
        except RuntimeError: print('after_rollback='+json.dumps(snapshot(path)))
