import sqlite3,tempfile,unittest
from pathlib import Path
import experiment as e
class Tests(unittest.TestCase):
 def setUp(self):self.temp=tempfile.TemporaryDirectory();self.path=Path(self.temp.name)/'test.db';e.initialize(self.path)
 def tearDown(self):self.temp.cleanup()
 def test_twelve_independent_connections_one_effect(self):
  self.assertEqual(e.concurrent_run(self.path),{'requests':12,'unique_receipts':1,'stock':99,'receipt_rows':1})
 def test_same_key_different_payload_is_conflict(self):
  e.purchase(self.path,'same',1)
  with self.assertRaises(e.Conflict):e.purchase(self.path,'same',2)
  self.assertEqual(e.snapshot(self.path),{'stock':99,'receipt_rows':1})
 def test_failure_before_receipt_rolls_back_stock(self):
  with self.assertRaises(RuntimeError):e.purchase(self.path,'retry',2,crash=True)
  self.assertEqual(e.snapshot(self.path),{'stock':100,'receipt_rows':0})
  e.purchase(self.path,'retry',2);self.assertEqual(e.snapshot(self.path),{'stock':98,'receipt_rows':1})
 def test_distinct_keys_have_distinct_effects(self):
  self.assertNotEqual(e.purchase(self.path,'a',1),e.purchase(self.path,'b',1));self.assertEqual(e.snapshot(self.path)['stock'],98)
 def test_no_negative_stock(self):
  for i in range(10):e.purchase(self.path,str(i),10)
  with self.assertRaisesRegex(ValueError,'stock'):e.purchase(self.path,'excess',1)
  self.assertEqual(e.snapshot(self.path),{'stock':0,'receipt_rows':10})
 def test_parameter_binding_keeps_sql_as_data(self):
  e.purchase(self.path,"'; DROP TABLE stock; --",1);self.assertEqual(e.snapshot(self.path)['stock'],99)
 def test_invalid_quantity_rejected(self):
  for value in (0,-1,11,True,1.5):
   with self.subTest(value=value),self.assertRaises(ValueError):e.purchase(self.path,'x',value)
if __name__=='__main__':unittest.main()
