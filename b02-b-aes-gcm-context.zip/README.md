# aes-gcm-context: reproducible synthetic experiment

Original defensive engineering code and tests. No article body or third-party source documents included.

## Run

Python 3.12 was used for the recorded run. In this folder:

    python -B -m unittest -v test_experiment.py
    python -B experiment.py

For AES-GCM, create an isolated environment and install the pinned dependencies from official PyPI:

    python -m pip install --index-url https://pypi.org/simple -r requirements.lock

The lock freezes the recorded version set; wheel hashes record the specific macOS arm64 artifacts, not every platform.

## Evidence and boundaries

Observed tests/demos used only synthetic inputs. evidence/run.json redacts local path strings only; timestamps, environment versions, code hashes and stdout/stderr hashes are retained.

- AAD 必须由已授权请求和可信记录关系决定；加密不能替代授权。
- 随机 nonce 测试不证明永久唯一；未实现每密钥容量策略、密钥管理或轮换。
- 相同上下文下旧封装仍有效；没有额外的可信版本与防回滚机制。
- NIST 来源只读出版页摘要，没有阅读全文或宣称算法认证。
- cryptography 50.0.2 锁与轮子哈希记录本次 macOS arm64 环境，不是跨平台通用锁。

AI-assisted original code; local tests actually executed. No production deployment or universal security certification is claimed.
