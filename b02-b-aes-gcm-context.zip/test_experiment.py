import unittest
import experiment as e

class AEADTests(unittest.TestCase):
    def setUp(self):
        self.key=e.AESGCM.generate_key(bit_length=256);self.ctx=e.Context('alpha','invoice','record_1')
        self.plain=b'synthetic data';self.env=e.seal(self.key,self.ctx,self.plain)
    def test_roundtrip_and_standard_sizes(self):
        self.assertEqual(e.open_record(self.key,self.ctx,self.env),self.plain)
        self.assertEqual(len(self.env.nonce),12);self.assertEqual(len(self.env.ciphertext),len(self.plain)+16)
    def test_empty_and_maximum_plaintext(self):
        for plain in [b'',b'x'*e.MAX_PLAINTEXT]:
            with self.subTest(length=len(plain)):self.assertEqual(e.open_record(self.key,self.ctx,e.seal(self.key,self.ctx,plain)),plain)
    def test_each_context_field_is_bound(self):
        for ctx in [e.Context('beta','invoice','record_1'),e.Context('alpha','note','record_1'),e.Context('alpha','invoice','record_2')]:
            with self.subTest(ctx=ctx),self.assertRaises(e.InvalidTag):e.open_record(self.key,ctx,self.env)
    def test_wrong_key_rejected(self):
        with self.assertRaises(e.InvalidTag):e.open_record(e.AESGCM.generate_key(bit_length=256),self.ctx,self.env)
    def test_nonce_ciphertext_and_tag_bit_flips_rejected(self):
        def flip(value,index):return value[:index]+bytes([value[index]^1])+value[index+1:]
        cases=[e.Envelope(flip(self.env.nonce,0),self.env.ciphertext),e.Envelope(self.env.nonce,flip(self.env.ciphertext,0)),e.Envelope(self.env.nonce,flip(self.env.ciphertext,len(self.env.ciphertext)-1))]
        for index,env in enumerate(cases):
            with self.subTest(case=index),self.assertRaises(e.InvalidTag):e.open_record(self.key,self.ctx,env)
    def test_truncation_and_shape_errors(self):
        for env in [None,e.Envelope(b'x'*11,self.env.ciphertext),e.Envelope(b'x'*13,self.env.ciphertext),e.Envelope(self.env.nonce,b'x'*15),e.Envelope(self.env.nonce,b'x'*(e.MAX_PLAINTEXT+17)),e.Envelope(bytearray(12),self.env.ciphertext)]:
            with self.subTest(env=type(env).__name__),self.assertRaises(ValueError):e.open_record(self.key,self.ctx,env)
        with self.assertRaises(e.InvalidTag):e.open_record(self.key,self.ctx,e.Envelope(self.env.nonce,self.env.ciphertext[:-1]))
    def test_canonical_aad_and_invalid_context(self):
        self.assertEqual(e.aad(self.ctx),b'{"record_id":"record_1","record_type":"invoice","schema":1,"tenant":"alpha"}')
        for ctx in [{'tenant':'alpha'},e.Context('','invoice','id'),e.Context('alpha','中文','id'),e.Context('alpha','invoice','x'*65)]:
            with self.subTest(ctx=ctx),self.assertRaises(ValueError):e.aad(ctx)
    def test_key_and_plaintext_bounds(self):
        for key in [b'x'*16,b'x'*31,b'x'*33,bytearray(32)]:
            with self.subTest(key=type(key).__name__),self.assertRaises(ValueError):e.seal(key,self.ctx,b'')
        for plain in ['text',bytearray(1),b'x'*(e.MAX_PLAINTEXT+1)]:
            with self.subTest(plain=type(plain).__name__),self.assertRaises(ValueError):e.seal(self.key,self.ctx,plain)
    def test_observed_nonce_variation_is_not_a_uniqueness_proof(self):
        envelopes=[e.seal(self.key,self.ctx,self.plain) for _ in range(100)]
        self.assertEqual(len({env.nonce for env in envelopes}),100)
        self.assertTrue(all(e.open_record(self.key,self.ctx,env)==self.plain for env in envelopes))
    def test_replaying_same_envelope_remains_valid(self):
        self.assertEqual(e.open_record(self.key,self.ctx,self.env),self.plain)
        self.assertEqual(e.open_record(self.key,self.ctx,self.env),self.plain)
if __name__=='__main__':unittest.main(verbosity=2)
