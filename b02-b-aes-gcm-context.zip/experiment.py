"""Mature cryptography AESGCM API, context bound as AAD; no custom cipher."""
from dataclasses import dataclass
import json,os,re
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag
MAX_PLAINTEXT=32768

@dataclass(frozen=True)
class Context:
    tenant:str
    record_type:str
    record_id:str

@dataclass(frozen=True)
class Envelope:
    nonce:bytes
    ciphertext:bytes

def aad(context):
    if type(context) is not Context:raise ValueError('trusted_context_required')
    for value in (context.tenant,context.record_type,context.record_id):
        if type(value) is not str or not re.fullmatch(r'[a-zA-Z0-9_-]{1,64}',value):raise ValueError('context_field')
    return json.dumps({'schema':1,'tenant':context.tenant,'record_type':context.record_type,
                       'record_id':context.record_id},sort_keys=True,separators=(',',':')).encode('ascii')

def key_check(key):
    if type(key) is not bytes or len(key)!=32:raise ValueError('aes256_key_required')

def seal(key,context,plaintext):
    key_check(key)
    if type(plaintext) is not bytes or len(plaintext)>MAX_PLAINTEXT:raise ValueError('plaintext_limit')
    associated=aad(context);nonce=os.urandom(12)
    return Envelope(nonce,AESGCM(key).encrypt(nonce,plaintext,associated))

def open_record(key,context,envelope):
    key_check(key)
    if (type(envelope) is not Envelope or type(envelope.nonce) is not bytes or len(envelope.nonce)!=12
            or type(envelope.ciphertext) is not bytes or not 16<=len(envelope.ciphertext)<=MAX_PLAINTEXT+16):raise ValueError('envelope_bounds')
    return AESGCM(key).decrypt(envelope.nonce,envelope.ciphertext,aad(context))

if __name__=='__main__':
    key=AESGCM.generate_key(bit_length=256);context=Context('alpha','invoice','record_1')
    envelope=seal(key,context,b'synthetic invoice, not customer data')
    result={'same_context_roundtrip':open_record(key,context,envelope)==b'synthetic invoice, not customer data',
            'nonce_bytes':len(envelope.nonce),'tag_overhead_bytes':len(envelope.ciphertext)-len(b'synthetic invoice, not customer data')}
    for label,changed in [('other_tenant',Context('beta','invoice','record_1')),('other_type',Context('alpha','note','record_1')),('other_id',Context('alpha','invoice','record_2'))]:
        try:open_record(key,changed,envelope)
        except InvalidTag:result[label]='InvalidTag'
    tampered=Envelope(envelope.nonce,bytes([envelope.ciphertext[0]^1])+envelope.ciphertext[1:])
    try:open_record(key,context,tampered)
    except InvalidTag:result['ciphertext_bit_flip']='InvalidTag'
    print(json.dumps(result))
