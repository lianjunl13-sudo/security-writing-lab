"""Bounded complete JSON document, not a streaming parser or OS sandbox."""
import json
import math

MAX_BYTES, MAX_DEPTH, MAX_NODES = 2048, 16, 100


def _reject_constant(_): raise ValueError('non_json_constant')


def _integer(value):
    if len(value.lstrip('-')) > 64: raise ValueError('integer_too_long')
    return int(value)


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result: raise ValueError('duplicate_key')
        result[key] = value
    return result


def bounded_load(raw):
    if type(raw) is not bytes or len(raw) > MAX_BYTES: raise ValueError('request_size')
    text = raw.decode('utf-8', errors='strict')
    # Lexical precheck protects this json.loads call from excessive nesting.
    depth, quoted, escaped = 0, False, False
    for char in text:
        if quoted:
            if escaped: escaped = False
            elif char == '\\': escaped = True
            elif char == '"': quoted = False
        elif char == '"': quoted = True
        elif char in '[{':
            depth += 1
            if depth > MAX_DEPTH: raise ValueError('nesting_limit')
        elif char in ']}': depth -= 1
    result = json.loads(text, parse_constant=_reject_constant, parse_int=_integer,
                        object_pairs_hook=_pairs)
    if type(result) is not dict: raise ValueError('object_required')
    nodes, stack = 0, [result]
    while stack:
        value = stack.pop(); nodes += 1
        if nodes > MAX_NODES: raise ValueError('node_limit')
        if type(value) is float and not math.isfinite(value): raise ValueError('finite_number_required')
        if isinstance(value, dict): stack.extend(value.keys()); stack.extend(value.values())
        elif isinstance(value, list): stack.extend(value)
        elif type(value) is str:
            try: value.encode('utf-8')
            except UnicodeError as exc: raise ValueError('invalid_unicode_scalar') from exc
    return result


def main():
    cases = {'normal': b'{"action":"preview","items":[1,2]}',
             'duplicate': b'{"role":"reader","role":"admin"}',
             'deep': ('{"a":' + '['*17 + '0' + ']'*17 + '}').encode(),
             'overflow': b'{"number":1e999}', 'braces_in_string': b'{"text":"[[[[{{"}'}
    result = {}
    for key, raw in cases.items():
        try: result[key] = {'accepted': bounded_load(raw)}
        except ValueError: result[key] = {'rejected': True}
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__': main()
