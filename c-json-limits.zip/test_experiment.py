import json
import unittest
import experiment as app


class BoundaryTests(unittest.TestCase):
    def test_normal_and_empty(self):
        self.assertEqual(app.bounded_load(b'{"a":[1,true,null]}'), {'a': [1,True,None]})
        self.assertEqual(app.bounded_load(b'{}'), {})
    def test_size_and_type(self):
        for raw in [b' '*2049, '{}', None]:
            with self.subTest(raw=type(raw)), self.assertRaises(ValueError): app.bounded_load(raw)
    def test_depth(self):
        with self.assertRaises(ValueError): app.bounded_load((' {"a":'+'['*17+'0'+']'*17+'}').encode())
    def test_string_escape_not_depth(self):
        data = {'text': '[[[[{'*30+'"\\'}
        self.assertEqual(app.bounded_load(json.dumps(data).encode()), data)
    def test_duplicate_and_nonstandard_numbers(self):
        for raw in [b'{"a":1,"a":2}', b'{"a":NaN}', b'{"a":Infinity}', b'{"a":1e999}', b'{"a":'+b'9'*65+b'}']:
            with self.subTest(raw=raw), self.assertRaises(ValueError): app.bounded_load(raw)
    def test_node_limit(self):
        with self.assertRaises(ValueError): app.bounded_load(json.dumps({'a':list(range(100))}).encode())
    def test_invalid_documents_and_unicode(self):
        for raw in [b'[]', b'{"a":1}{}', b'{"a":}', b'{"a":"\xff"}', b'{"a":"\\ud800"}']:
            with self.subTest(raw=raw), self.assertRaises(ValueError): app.bounded_load(raw)


if __name__ == '__main__': unittest.main()
