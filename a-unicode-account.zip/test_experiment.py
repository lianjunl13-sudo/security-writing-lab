import unittest,unicodedata
from experiment import account_key,Registry,Rejected
class UnicodeTests(unittest.TestCase):
    def test_casefold(self):self.assertEqual(account_key('Alice'),'alice')
    def test_width(self):self.assertEqual(account_key('ＡＬＩＣＥ'),'alice')
    def test_nfkc_number(self):self.assertEqual(account_key('user①'),'user1')
    def test_casefold_expansion(self):self.assertEqual(account_key('Straße'),'strasse')
    def test_han(self):self.assertEqual(account_key('中文用户'),'中文用户')
    def test_collision(self):
        r=Registry();r.register('Alice')
        with self.assertRaises(Rejected):r.register('ＡＬＩＣＥ')
    def test_zero_width(self):
        with self.assertRaises(Rejected):account_key('user\u200bname')
    def test_bidi(self):
        with self.assertRaises(Rejected):account_key('abc\u202edef')
    def test_cyrillic_homoglyph_rejected(self):
        with self.assertRaises(Rejected):account_key('аlice')
    def test_normalized_length(self):
        with self.assertRaises(Rejected):account_key('ß'*17)
    def test_separators_stay_distinct(self):self.assertNotEqual(account_key('a-b'),account_key('a_b'))
    def test_invisible_and_space(self):
        for s in ['abc def','abc\tdef','abc\ufe0f']:
            with self.assertRaises(Rejected):account_key(s)
    def test_nfc_equivalence_both_rejected_by_policy(self):
        for s in ['café','cafe\u0301']:
            with self.assertRaises(Rejected):account_key(s)
    def test_raw_and_normalized_limits(self):
        for s in ['', 'ab', 'a'*65]:
            with self.assertRaises(Rejected):account_key(s)
if __name__=='__main__':unittest.main(verbosity=2)
