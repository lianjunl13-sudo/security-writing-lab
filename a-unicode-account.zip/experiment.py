"""Explicit account-key policy; not a universal Unicode confusable detector."""
import unicodedata as ud
class Rejected(ValueError):pass

def account_key(raw):
    if type(raw) is not str or not 1<=len(raw)<=64:raise Rejected('raw length or type')
    # Allow letters, numbers and a small separator set; reject controls before normalization.
    if any(ud.category(c)[0] not in 'LNM' and c not in '_-' for c in raw):raise Rejected('character class')
    key=ud.normalize('NFKC',ud.normalize('NFKC',raw).casefold())
    if not 3<=len(key)<=32 or not key[0].isalnum():raise Rejected('normalized length or start')
    if any(ud.category(c)[0] not in 'LNM' and c not in '_-' for c in key):raise Rejected('normalized class')
    # Conservative product policy: ASCII Latin + Han, no other writing systems.
    for c in key:
        if c in '_-' or c.isascii() and c.isalnum():continue
        if '\u4e00'<=c<='\u9fff':continue
        raise Rejected('unsupported script or combining sequence')
    return key

class Registry:
    def __init__(self):self.keys={}
    def register(self,display):
        key=account_key(display)
        if key in self.keys:raise Rejected('normalized collision')
        self.keys[key]=display
        return key

if __name__=='__main__':
    import json
    r=Registry();output={}
    for name in ['Alice','ＡＬＩＣＥ','中文用户','аlice','user\u200bname','a-b','a_b']:
        try:output[name]={'key':r.register(name),'status':'registered'}
        except Rejected as e:output[name]=str(e)
    output['unicode_database']=ud.unidata_version
    print(json.dumps(output,ensure_ascii=False,indent=2))
