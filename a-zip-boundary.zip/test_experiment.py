import unittest,io,zipfile,tempfile,stat
from pathlib import Path
from experiment import extract,Rejected
class ZipTests(unittest.TestCase):
    def setUp(self):self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup)
    def blob(self,items,compression=zipfile.ZIP_STORED):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w',compression=compression) as z:
            for n,v in items:z.writestr(n,v)
        return b.getvalue()
    def reject(self,blob,**limits):
        before=set(Path(self.t.name).iterdir())
        with self.assertRaises(Rejected):extract(blob,self.t.name,**limits)
        self.assertEqual(before,set(Path(self.t.name).iterdir()))
    def test_nested(self):
        p=extract(self.blob([('a/b.txt',b'ok')]),self.t.name);self.assertEqual((p/'a/b.txt').read_bytes(),b'ok')
    def test_traversal(self):self.reject(self.blob([('../escape',b'x')]))
    def test_absolute(self):self.reject(self.blob([('/escape',b'x')]))
    def test_windows(self):
        for n in ['C:/escape','a\\b','a:stream']:self.reject(self.blob([(n,b'x')]))
    def test_empty_dot_component(self):
        for n in ['a//b','a/./b','a/../b']:self.reject(self.blob([(n,b'x')]))
    def test_case_collision(self):self.reject(self.blob([('Readme',b'a'),('README',b'b')]))
    def test_symlink(self):
        info=zipfile.ZipInfo('link');info.create_system=3;info.external_attr=(stat.S_IFLNK|0o777)<<16
        self.reject(self.blob([(info,b'../../outside')]))
    def test_file_count(self):self.reject(self.blob([('a',b'a'),('b',b'b')]),max_files=1)
    def test_output_limit(self):self.reject(self.blob([('a',b'x'*101)]),max_output=100)
    def test_ratio_limit(self):self.reject(self.blob([('a',b'x'*10000)],zipfile.ZIP_DEFLATED),max_ratio=10)
    def test_corruption_cleans_stage(self):
        blob=bytearray(self.blob([('a',b'hello-synthetic')]));offset=blob.index(b'hello-synthetic');blob[offset]^=1;self.reject(bytes(blob))
    def test_file_parent_conflict_cleanup(self):self.reject(self.blob([('a',b'a'),('a/b',b'b')]))
    def test_single_directory_separator_allowed(self):
        p=extract(self.blob([('docs/',b''),('docs/a',b'ok')]),self.t.name)
        self.assertEqual((p/'docs/a').read_bytes(),b'ok')
    def test_multiple_terminal_separators(self):
        for name in ['a//','a///','a/b///']:
            self.reject(self.blob([(name,b'')]))
    def test_cleanup_failure_observable(self):
        from unittest.mock import patch
        with patch('experiment.shutil.rmtree',side_effect=OSError('synthetic cleanup failure')):
            with self.assertRaisesRegex(Rejected,'cleanup failed'):
                extract(self.blob([('a',b'a'),('a/b',b'b')]),self.t.name)
        self.assertEqual(len(list(Path(self.t.name).iterdir())),1)
    def test_existing_parent_file_untouched(self):
        p=Path(self.t.name)/'keep';p.write_text('original');self.reject(self.blob([('../keep',b'overwrite')]));self.assertEqual(p.read_text(),'original')
if __name__=='__main__':unittest.main(verbosity=2)
