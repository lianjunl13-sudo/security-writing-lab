"""Extract a small untrusted ZIP into a new private staging directory."""
import io,zipfile,stat,shutil,tempfile
from pathlib import Path
class Rejected(ValueError):pass

def extract(blob,parent,max_files=20,max_output=65536,max_ratio=100):
    if len(blob)>131072:raise Rejected('input budget')
    stage=None
    try:
        with zipfile.ZipFile(io.BytesIO(blob)) as z:
            infos=z.infolist()
            if len(infos)>max_files:raise Rejected('member count')
            planned=[];seen=set();claimed=0
            for item in infos:
                name=item.orig_filename
                if not name or '\x00' in name or '\\' in name or ':' in name or name.startswith('/'):
                    raise Rejected('path spelling')
                # Permit one terminal separator for a directory, not an empty path segment.
                member_path=name[:-1] if name.endswith('/') else name
                parts=member_path.split('/')
                if any(part in ('','.','..') for part in parts):raise Rejected('path component')
                key='/'.join(parts).casefold()
                if key in seen:raise Rejected('duplicate or case collision')
                seen.add(key)
                kind=stat.S_IFMT(item.external_attr>>16)
                if kind not in (0,stat.S_IFREG,stat.S_IFDIR):raise Rejected('special member')
                if item.flag_bits&1:raise Rejected('encrypted member')
                if item.compress_type not in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED):raise Rejected('compression method')
                claimed+=item.file_size
                if claimed>max_output or item.file_size>max_ratio*max(1,item.compress_size):raise Rejected('declared output budget')
                planned.append((item,parts))
            stage=Path(tempfile.mkdtemp(prefix='unpack-',dir=parent))
            actual=0
            for item,parts in planned:
                target=stage.joinpath(*parts)
                if item.is_dir():target.mkdir(parents=True,exist_ok=True);continue
                target.parent.mkdir(parents=True,exist_ok=True)
                with z.open(item) as source,target.open('xb') as out:
                    while True:
                        chunk=source.read(min(4096,max_output-actual+1))
                        if not chunk:break
                        actual+=len(chunk)
                        if actual>max_output:raise Rejected('actual output budget')
                        out.write(chunk)
            return stage
    except Exception as e:
        if stage is not None:
            try:shutil.rmtree(stage)
            except OSError:raise Rejected('cleanup failed; staging directory requires recovery') from None
        if isinstance(e,Rejected):raise
        raise Rejected('invalid archive') from None

if __name__=='__main__':
    import json
    output={}
    with tempfile.TemporaryDirectory() as parent:
        for label,name in [('normal','docs/readme.txt'),('traversal','../outside.txt'),('windows_path','C:/outside.txt')]:
            buffer=io.BytesIO()
            with zipfile.ZipFile(buffer,'w') as z:z.writestr(name,b'local synthetic text')
            try:
                path=extract(buffer.getvalue(),parent);output[label]={'status':'extracted','content':(path/name).read_text()};shutil.rmtree(path)
            except Rejected:output[label]='rejected'
        output['remaining_staging_directories']=len(list(Path(parent).iterdir()))
    print(json.dumps(output,ensure_ascii=False,indent=2))
