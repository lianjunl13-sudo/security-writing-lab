# download-disposition 本地合成数据实验

本附件只含原创代码、测试、实际运行记录及适用的依赖锁。没有文章正文或外部来源全文，没有真实用户资料、生产凭据或私钥。AI辅助编写；测试实际执行。

依赖Python标准库。运行：

```sh
python3 -B -m unittest -v
python3 -B experiment.py
```

范围：仅本地合成输入。没有浏览器、真实网络服务或生产环境集成验证；实际解释器、时间、源码摘要见evidence/run.json。
