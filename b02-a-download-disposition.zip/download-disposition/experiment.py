"""Build a single ASCII Content-Disposition value for fixed report types."""
import unicodedata
from urllib.parse import quote
TYPES={'csv':'.csv','pdf':'.pdf','txt':'.txt'}
ATTR_CHAR="!#$&+-.^_`|~"
class Rejected(ValueError):pass

def disposition(name,kind='csv'):
    if type(kind)is not str or kind not in TYPES:raise Rejected('report_kind')
    if type(name)is not str or not 1<=len(name)<=120:raise Rejected('filename_type_or_length')
    if any(unicodedata.category(c).startswith('C')for c in name):raise Rejected('control_or_format_character')
    if any(c in name for c in '/\\:')or name[-1]in ' .':raise Rejected('basename_required')
    encoded=name.encode('utf-8')
    if len(encoded)>240:raise Rejected('filename_byte_budget')
    suffix=TYPES[kind]
    if not name.lower().endswith(suffix):raise Rejected('extension_policy')
    fallback='report'+suffix
    value=f'attachment; filename="{fallback}"; filename*=UTF-8\'\'{quote(name,safe=ATTR_CHAR)}'
    if not value.isascii()or any(ord(c)<32 or ord(c)>126 for c in value):raise AssertionError('header invariant')
    return value

if __name__=='__main__':
    import json
    cases=['report.csv','月度报表.csv','report;"draft".csv','a\r\nX-Synthetic: yes.csv','../report.csv']
    results={}
    for name in cases:
        try:results[name]={'status':'built','header_value':disposition(name)}
        except Rejected as e:results[name]={'status':'rejected','reason':str(e)}
    print(json.dumps(results,ensure_ascii=False,indent=2))
