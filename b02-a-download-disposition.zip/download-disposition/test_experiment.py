import re,unittest
from urllib.parse import unquote
from experiment import disposition,Rejected
class DownloadTests(unittest.TestCase):
    def decode(self,value):
        m=re.fullmatch(r'attachment; filename="(report\.(?:csv|pdf|txt))"; filename\*=UTF-8\x27\x27(.+)',value)
        self.assertIsNotNone(m);return m[1],unquote(m[2],encoding='utf-8',errors='strict')
    def test_ascii(self):self.assertEqual(self.decode(disposition('report.csv')),('report.csv','report.csv'))
    def test_chinese(self):self.assertEqual(self.decode(disposition('月度报表.csv')),('report.csv','月度报表.csv'))
    def test_quotes_semicolon(self):
        v=disposition('report;"draft".csv');self.assertIn('%3B%22',v);self.assertEqual(self.decode(v)[1],'report;"draft".csv')
    def test_percent_not_interpreted(self):self.assertEqual(self.decode(disposition('report%20x.csv'))[1],'report%20x.csv');self.assertIn('%2520',disposition('report%20x.csv'))
    def test_apostrophe_star_encoded(self):
        v=disposition("report'*.csv");self.assertTrue(v.endswith('report%27%2A.csv'))
    def test_crlf_and_controls(self):
        for c in ['\r','\n','\x00','\x7f','\t','\u202e','\u200b','\ud800']:
            with self.assertRaises(Rejected):disposition('a'+c+'.csv')
    def test_path_spelling(self):
        for name in ['../a.csv','/a.csv','a\\b.csv','C:a.csv']:
            with self.assertRaises(Rejected):disposition(name)
    def test_wrong_extension_and_tail(self):
        for name in ['a.csv.exe','a.csv.','a.csv ','a.pdf']:
            with self.assertRaises(Rejected):disposition(name)
    def test_type_and_empty(self):
        for name in ['',None,42]:
            with self.assertRaises(Rejected):disposition(name)
    def test_character_budget(self):
        with self.assertRaises(Rejected):disposition('a'*117+'.csv')
    def test_utf8_budget(self):
        self.decode(disposition('中'*78+'.csv'))
        with self.assertRaisesRegex(Rejected,'byte_budget'):disposition('中'*79+'.csv')
    def test_supported_kind(self):self.assertEqual(self.decode(disposition('说明.pdf','pdf'))[0],'report.pdf')
    def test_unknown_kind(self):
        for kind in ['html',{},None]:
            with self.assertRaises(Rejected):disposition('a.csv',kind)
    def test_output_ascii_single_line(self):
        for name in ['a b.csv','月报.csv','"a;b".csv']:
            v=disposition(name);self.assertTrue(v.isascii());self.assertNotIn('\r',v);self.assertNotIn('\n',v);self.assertEqual(v.count('filename='),1);self.assertEqual(v.count('filename*='),1)
if __name__=='__main__':unittest.main(verbosity=2)
