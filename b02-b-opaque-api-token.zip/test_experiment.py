import hashlib,tempfile,unittest
from pathlib import Path
import experiment as e

class OpaqueTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'state.db';e.initialize(self.path)
        self.raw=e.issue(self.path,'alpha',frozenset({'reports:read'}),now=100,ttl=10)
    def auth(self,raw=None,**kw):
        args={'required_scope':'reports:read','target_tenant':'alpha','now':101};args.update(kw)
        return e.authorize(self.path,self.raw if raw is None else raw,**args)
    def test_read_success_returns_no_secret(self):
        result=self.auth();self.assertEqual(result,{'tenant':'alpha','scope':'reports:read','selector':self.raw[4:20]})
        self.assertNotIn('digest',result);self.assertNotIn(self.raw,str(result))
    def test_digest_storage_without_raw(self):
        with e.connection(self.path) as db:
            dump='\n'.join(db.iterdump());digest=db.execute('SELECT digest FROM tokens').fetchone()[0]
        self.assertNotIn(self.raw,dump);self.assertEqual(digest,hashlib.sha256(self.raw.encode()).hexdigest())
    def test_scope_and_tenant_denials(self):
        for args in [{'required_scope':'reports:write'},{'required_scope':'admin'},{'target_tenant':'beta'}]:
            with self.subTest(args=args),self.assertRaises(e.InvalidAPIKey):self.auth(**args)
    def test_exact_expiry_and_before(self):
        self.assertEqual(self.auth(now=109)['scope'],'reports:read')
        for now in [110,111]:
            with self.subTest(now=now),self.assertRaises(e.InvalidAPIKey):self.auth(now=now)
    def test_same_selector_wrong_secret(self):
        secret=self.raw[21:];changed=('A' if secret[0]!='A' else 'B')+secret[1:]
        with self.assertRaises(e.InvalidAPIKey):self.auth(self.raw[:21]+changed)
    def test_unknown_selector_and_prefix_are_not_authority(self):
        unknown='0'*16 if self.raw[4:20]!='0'*16 else '1'*16
        for raw in ['lab_'+unknown+self.raw[20:],'dev_'+self.raw[4:]]:
            with self.subTest(raw=raw[:4]),self.assertRaises(e.InvalidAPIKey):self.auth(raw)
    def test_revocation_next_lookup_and_isolation(self):
        other=e.issue(self.path,'alpha',frozenset({'reports:read','reports:write'}),now=100)
        self.assertEqual(e.revoke(self.path,self.raw[4:20]),1)
        with self.assertRaises(e.InvalidAPIKey):self.auth()
        self.assertEqual(self.auth(other,required_scope='reports:write')['scope'],'reports:write')
        self.assertEqual(e.revoke(self.path,'missing'),0)
    def test_malformed_tokens(self):
        for raw in ['',self.raw[:-1],self.raw+'a',self.raw.replace('.','..'),123,'汉'*64]:
            with self.subTest(raw=type(raw).__name__),self.assertRaises(e.InvalidAPIKey):self.auth(raw)
    def test_issuer_input_bounds(self):
        for change in [{'tenant':'Alpha'},{'tenant':''},{'scopes':frozenset()},{'scopes':{'reports:read'}},{'scopes':frozenset({'admin'})},{'now':True},{'now':-1},{'ttl':0},{'ttl':3601}]:
            args={'tenant':'alpha','scopes':frozenset({'reports:read'}),'now':100};args.update(change)
            with self.subTest(change=change),self.assertRaises(ValueError):e.issue(self.path,**args)
    def test_authorizer_input_bounds(self):
        for change in [{'now':True},{'now':-1},{'now':1.5},{'now':253402300800},{'target_tenant':None},{'required_scope':None}]:
            with self.subTest(change=change),self.assertRaises(e.InvalidAPIKey):self.auth(**change)
if __name__=='__main__':unittest.main(verbosity=2)
