"""Random opaque tokens: indexed public selector plus digest, scope and revocation."""
import hashlib,hmac,json,re,secrets,sqlite3,tempfile
from pathlib import Path
from contextlib import contextmanager
@contextmanager
def connection(*args, **kwargs):
    db=sqlite3.connect(*args, **kwargs)
    try:
        with db:
            yield db
    finally:
        db.close()

SCOPES=frozenset({'reports:read','reports:write'})
class InvalidAPIKey(PermissionError):pass

def initialize(path):
    with connection(path) as db:
        db.execute('CREATE TABLE tokens(selector TEXT PRIMARY KEY,digest TEXT NOT NULL,tenant TEXT NOT NULL,scopes TEXT NOT NULL,expires_at INTEGER NOT NULL,revoked INTEGER NOT NULL DEFAULT 0)')

def issue(path,tenant,scopes,*,now,ttl=3600):
    if type(tenant) is not str or not re.fullmatch(r'[a-z0-9_-]{1,32}',tenant):raise ValueError('tenant')
    if type(scopes) is not frozenset or not scopes or not scopes<=SCOPES:raise ValueError('scopes')
    if type(now) is not int or not 0<=now<=253402300799 or type(ttl) is not int or not 1<=ttl<=3600:raise ValueError('clock_or_ttl')
    selector=secrets.token_hex(8);secret=secrets.token_urlsafe(32)
    raw='lab_'+selector+'.'+secret;digest=hashlib.sha256(raw.encode('ascii')).hexdigest()
    with connection(path) as db:
        db.execute('INSERT INTO tokens(selector,digest,tenant,scopes,expires_at) VALUES(?,?,?,?,?)',
                   (selector,digest,tenant,json.dumps(sorted(scopes)),now+ttl))
    return raw

def authorize(path,raw,*,required_scope,target_tenant,now):
    if (type(raw) is not str or not re.fullmatch(r'lab_[0-9a-f]{16}\.[A-Za-z0-9_-]{43}',raw)
            or type(required_scope) is not str or required_scope not in SCOPES
            or type(target_tenant) is not str or type(now) is not int or not 0<=now<=253402300799):raise InvalidAPIKey('invalid_api_key')
    selector=raw[4:20]
    with connection(path) as db:
        row=db.execute('SELECT digest,tenant,scopes,expires_at,revoked FROM tokens WHERE selector=?',(selector,)).fetchone()
    if not row:raise InvalidAPIKey('invalid_api_key')
    digest,tenant,scopes,expires,revoked=row
    if (not hmac.compare_digest(hashlib.sha256(raw.encode('ascii')).hexdigest(),digest)
            or revoked or now>=expires or tenant!=target_tenant or required_scope not in json.loads(scopes)):
        raise InvalidAPIKey('invalid_api_key')
    return {'tenant':tenant,'scope':required_scope,'selector':selector}

def revoke(path,selector):
    # Trusted administration operation; not exposed to unauthenticated request data.
    with connection(path) as db:return db.execute('UPDATE tokens SET revoked=1 WHERE selector=?',(selector,)).rowcount

if __name__=='__main__':
    with tempfile.TemporaryDirectory() as temp:
        path=Path(temp)/'keys.db';initialize(path);raw=issue(path,'alpha',frozenset({'reports:read'}),now=100)
        result={'read_scope':authorize(path,raw,required_scope='reports:read',target_tenant='alpha',now=101)['scope']}
        for label,scope,tenant in [('write_scope','reports:write','alpha'),('other_tenant','reports:read','beta')]:
            try:authorize(path,raw,required_scope=scope,target_tenant=tenant,now=101)
            except InvalidAPIKey:result[label]='rejected'
        with connection(path) as db:result['raw_token_present_in_logical_dump']=raw in '\n'.join(db.iterdump())
        revoke(path,raw[4:20])
        try:authorize(path,raw,required_scope='reports:read',target_tenant='alpha',now=102)
        except InvalidAPIKey:result['after_committed_revocation']='rejected'
        print(json.dumps(result))
