# opaque-api-token: reproducible synthetic experiment

Original defensive engineering code and tests. No article body or third-party source documents included.

## Run

Python 3.12 was used for the recorded run. In this folder:

    python -B -m unittest -v test_experiment.py
    python -B experiment.py

## Evidence and boundaries

Observed tests/demos used only synthetic inputs. evidence/run.json redacts local path strings only; timestamps, environment versions, code hashes and stdout/stderr hashes are retained.

- 仅内部签发、验证和可信管理撤销；没有 HTTP 网关、客户管理界面或真实凭据。
- 撤销承诺是提交后的下一次查库拒绝，不取消已经授权或完成的业务操作。
- 无授权缓存、复制副本与跨区域一致性测试。
- 选择器随机碰撞导致插入失败，未实现生产签发重试策略。
- 目标租户和所需范围由服务端业务路由确定，不能直接信任客户端自报。

AI-assisted original code; local tests actually executed. No production deployment or universal security certification is claimed.
